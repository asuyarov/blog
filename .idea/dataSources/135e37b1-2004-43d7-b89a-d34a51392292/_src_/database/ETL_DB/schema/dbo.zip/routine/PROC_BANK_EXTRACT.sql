


CREATE PROCEDURE [dbo].[PROC_BANK_EXTRACT] (@DATE NVARCHAR(10), @PATH NVARCHAR(300), @CONTRACT INT, @USER VARCHAR(6), @CLEARF INT)
AS
BEGIN 
SET LANGUAGE ENGLISH;
IF @USER IS NULL OR @USER ='' OR @USER =' '
SET @USER = 'ADMIN';
DECLARE @SEQ BIGINT;
DECLARE @FULLCOUNT INT;
SELECT @SEQ = NEXT VALUE FOR [dbo].[SEQ_BANK_EXTRACT_LOG];
INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 0, 'Запуск процедуры!', @USER,  GETDATE()); 
--Создание темповой таблицы для добавление записей на вывод по окончанию процедуры
IF OBJECT_ID(N'TEMPDB..#MESSAGE',N'U') IS NOT NULL DROP TABLE #MESSAGE
CREATE TABLE #MESSAGE(TEXT NVARCHAR(1000));
--Создание темповой таблицы для добавление записей в случае критических ошибок и вывода их по окнчанию процедуры
IF OBJECT_ID(N'TEMPDB..#ERRORMESSAGE',N'U') IS NOT NULL DROP TABLE #ERRORMESSAGE
CREATE TABLE #ERRORMESSAGE(TEXT NVARCHAR(1000));
--Таблица для предупреждений
IF OBJECT_ID(N'TEMPDB..#WARMESSAGE',N'U') IS NOT NULL DROP TABLE #WARMESSAGE
CREATE TABLE #WARMESSAGE(TEXT NVARCHAR(1000));

--Проверяем и проставляем флаг очистки данных перед заливкой
IF @CLEARF = 0 OR @CLEARF = '' OR @CLEARF IS NULL
   BEGIN 
   UPDATE [dbo].[BANK_EXTRACT_MAIN] SET VALUE_IN = '0', VALUE_OUT = 'FALSE' WHERE NAME = 'CLEAR_FLAG';
   INSERT INTO [dbo].[BANK_EXTRACT_LOG] VALUES(@SEQ, 0, 'Флаг очистки данных = FALSE', @USER, GETDATE());
   END;
ELSE 
BEGIN 
     IF @CLEARF = 1 
    	 BEGIN 
	     UPDATE [dbo].[BANK_EXTRACT_MAIN] SET VALUE_IN = '1', VALUE_OUT = 'TRUE' WHERE NAME = 'CLEAR_FLAG';
	     INSERT INTO [dbo].[BANK_EXTRACT_LOG] VALUES(@SEQ, 2, 'Флаг очистки данных = TRUE', @USER, GETDATE());
		 INSERT INTO #MESSAGE VALUES ('Внимание! Флаг очистки данных = TRUE');	 
	     END;
     ELSE 
	 BEGIN
	 INSERT INTO [dbo].[BANK_EXTRACT_LOG] VALUES(@SEQ, 1, 'Некорректный признак очистки данных, значение: '+convert(varchar(max), @CLEARF) + '. Допустимые значение: 0 или 1.', @USER, GETDATE()); 
     INSERT INTO #ERRORMESSAGE VALUES ('Некорректный признак очистки данных. Допустимые значение: 1 или 0.');
	 GOTO ERROR;
	 END;
END;

--Заполняем значения по дефолту
/*UPDATE [ETL_DB].[DBO].[BANK_EXTRACT_FLAG]
       SET DATE_FLAG = 0;
UPDATE [ETL_DB].[DBO].[BANK_EXTRACT_FLAG]
       SET PATH_FLAG = 0;*/
UPDATE [ETL_DB].[DBO].[BANK_EXTRACT_MAIN]
       SET VALUE_IN = CONVERT(NVARCHAR, GETDATE()), VALUE_OUT = CONVERT(NVARCHAR, GETDATE(),104)
	   WHERE ID = 2
UPDATE [ETL_DB].[DBO].[BANK_EXTRACT_MAIN] 
	   SET VALUE_IN = (SELECT VALUE_IN FROM [ETL_DB].[DBO].[BANK_EXTRACT_MAIN] WHERE ID=0), 
		    VALUE_OUT = (SELECT VALUE_OUT FROM [ETL_DB].[DBO].[BANK_EXTRACT_MAIN] WHERE ID=0) 
	   WHERE ID=1;
INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 0, 'Проставлены значения по дефолту.', @USER, GETDATE()); 
UPDATE [ETL_DB].[DBO].[BANK_EXTRACT_MAIN] SET VALUE_IN = @USER, VALUE_OUT = @USER WHERE NAME = 'USER';
--ОБРАБОТКА ДАТЫ!
--Предпринимается попытка сконвертировать входящую дату
INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 0, 'ОБРАБОТКА ДАТЫ', @USER, GETDATE());
IF @DATE = '-1' OR @DATE IS NULL OR @DATE = '' OR @DATE = ' ' 
BEGIN
SELECT  @DATE = CONVERT(NVARCHAR, GETDATE(),104);
UPDATE [ETL_DB].[DBO].[BANK_EXTRACT_MAIN]
       SET VALUE_IN = CONVERT(NVARCHAR, GETDATE()), VALUE_OUT = @DATE
WHERE ID=2;
INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 0, 'Проставлено значение даты: '+@DATE, @USER, GETDATE()); 
--Успшный флаг проверки даты
/*UPDATE [ETL_DB].[DBO].[BANK_EXTRACT_FLAG]
                               SET DATE_FLAG = 1;*/
INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 0, 'Проставлен флаг корректности даты ', @USER, GETDATE()); 
INSERT INTO #MESSAGE VALUES ('Дата загрузки: '+@DATE);
INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 0, 'Дата загрузки: '+@DATE, @USER, GETDATE());  
END;
ELSE BEGIN
BEGIN TRY
--Если входящая дата больше текущей или меньше 2015 необходимо оповестить пользователя об этом
IF CONVERT(DATE, @DATE, 104) > CONVERT(DATE, GETDATE(), 104) OR CONVERT(INT, SUBSTRING(@DATE,7,4))<2015 
BEGIN
--Проставляется флаг некорректности даты
/*UPDATE [ETL_DB].[DBO].[BANK_EXTRACT_FLAG]
    SET DATE_FLAG = 2;*/
INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 2, 'Проставлен флаг не корректности даты, дата менее 2015 или больше текущей. Не критично для выполнения процедуры. ', @USER, GETDATE()); 
--При этом дата добавляется в управляющую таблицу
UPDATE [ETL_DB].[DBO].[BANK_EXTRACT_MAIN]
     SET VALUE_IN = @DATE,
	     VALUE_OUT = CONVERT(NVARCHAR, @DATE, 104)
     WHERE ID=2;
INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 2, 'При этом добавлена дата в управляющую таблицу: '+@DATE, @USER, GETDATE()); 
--Проверка: если год меньше 2015
IF CONVERT(INT, SUBSTRING(@DATE,7,4))<2015
                        BEGIN 
						INSERT INTO #MESSAGE VALUES ('Внимание! Некорректный год ('+SUBSTRING(@DATE,7,4)+') загрузка выписок не осуществляется ранее даты 01.01.2015'); 
						INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 2, 'Некорректный год ('+SUBSTRING(@DATE,7,4)+') загрузка выписок не осуществляется ранее даты 01.01.2015. Не критическое сообщение.', @USER, GETDATE());  
						END;
--Проверка: если год больше текущего
IF CONVERT(INT, SUBSTRING(@DATE,7,4))>CONVERT(INT, SUBSTRING(CONVERT(NVARCHAR, GETDATE(),104),7,4)) 
                        BEGIN INSERT INTO #MESSAGE VALUES ('Внимание! Некорректный год ('+SUBSTRING(@DATE,7,4)+') не может быть больше текущего ('+ SUBSTRING(CONVERT(NVARCHAR, GETDATE(),104),7,4)+')'); 
						INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 2, 'Некорректный год ('+SUBSTRING(@DATE,7,4)+') не может быть больше текущего ('+ SUBSTRING(CONVERT(NVARCHAR, GETDATE(),104),7,4)+'). Не критическое сообщение.', @USER, GETDATE());  
						END;
--Проверка: если года одинаковые, но месяц больше текущего
IF (CONVERT(INT, SUBSTRING(@DATE,7,4))=CONVERT(INT, SUBSTRING(CONVERT(NVARCHAR, GETDATE(),104),7,4)) AND CONVERT(INT, SUBSTRING(@DATE,4,2))>CONVERT(INT, SUBSTRING(CONVERT(NVARCHAR, GETDATE(),104),4,2)))
                        BEGIN 
						INSERT INTO #MESSAGE VALUES ('Внимание! Некорректный месяц ('+SUBSTRING(@DATE,4,2)+') не может быть больше текущего ('+SUBSTRING(CONVERT(NVARCHAR, GETDATE(),104),4,2)+')'); 
						INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 2, 'Некорректный месяц ('+SUBSTRING(@DATE,4,2)+') не может быть больше текущего ('+SUBSTRING(CONVERT(NVARCHAR, GETDATE(),104),4,2)+'). Не критическое сообщение.', @USER, GETDATE());            
						END;
--Проверка: если года и месяца одинаковые, но день больше текущего
IF (CONVERT(INT, SUBSTRING(@DATE,7,4))=CONVERT(INT, SUBSTRING(CONVERT(NVARCHAR, GETDATE(),104),7,4)) AND CONVERT(INT, SUBSTRING(@DATE,4,2))=CONVERT(INT, SUBSTRING(CONVERT(NVARCHAR, GETDATE(),104),4,2)) AND CONVERT(INT, SUBSTRING(@DATE,1,2))>CONVERT(INT, SUBSTRING(CONVERT(NVARCHAR, GETDATE(),104),1,2)))
                        BEGIN 
						INSERT INTO #MESSAGE VALUES ('Внимание! Некорректный день ('+SUBSTRING(@DATE,1,2)+') не может быть больше текущего дня ('+SUBSTRING(CONVERT(NVARCHAR, GETDATE(),104),1,2) +')'); 
						INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 2, 'Некорректный день ('+SUBSTRING(@DATE,1,2)+') не может быть больше текущего дня ('+SUBSTRING(CONVERT(NVARCHAR, GETDATE(),104),1,2) +'). Не критическое сообщение.', @USER, GETDATE());            
						END;
END
ELSE 
BEGIN
--Если дата корректная, то она записывается в управляющую таблицу
UPDATE [ETL_DB].[DBO].[BANK_EXTRACT_MAIN]
     SET VALUE_IN = @DATE,
	     VALUE_OUT = CONVERT(NVARCHAR, @DATE, 104)
     WHERE ID=2;
--Также проставляется флаг успешной проверки даты
/*UPDATE [ETL_DB].[DBO].[BANK_EXTRACT_FLAG]
     SET DATE_FLAG = 1;*/
	 END;
INSERT INTO #MESSAGE VALUES( 'Дата загрузки: '+CONVERT(NVARCHAR, @DATE, 104));
INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 0, 'Дата загрузки: '+CONVERT(NVARCHAR, @DATE, 104), @USER, GETDATE());            
END TRY
--Если не удалось сконвертировать дату, то необходимо найти причину:
BEGIN CATCH
begin
--Сообщаем об ошибке
INSERT INTO #ERRORMESSAGE VALUES ('Ошибка конвертации даты');
INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 1, 'Ошибка при попытке конвертации даты, введенной пользователем: '+@DATE, @USER, GETDATE());            
--Проставляем флаг ошибки даты
/*UPDATE [ETL_DB].[DBO].[BANK_EXTRACT_FLAG]
       SET DATE_FLAG = 0;*/
--Проставляем дефолтовые значение даты
UPDATE [ETL_DB].[DBO].[BANK_EXTRACT_MAIN]
       SET VALUE_IN = CONVERT(NVARCHAR, GETDATE()), VALUE_OUT = CONVERT(NVARCHAR, GETDATE(),104)
	   WHERE ID = 2
--Парсим ошибку конверта
--Возможно значение содержит буквы
IF ISNUMERIC(SUBSTRING(@DATE,1,2))=0 OR ISNUMERIC(SUBSTRING(@DATE,4,2))=0 OR ISNUMERIC(SUBSTRING(@DATE,7,4))=0
                        BEGIN 
						INSERT INTO #ERRORMESSAGE VALUES ('ВНИМАНИЕ! Значение даты может содержать только цифры и разделительный знак "." в формате DD.MM.YYYY');
						INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ,1, 'Значение даты может содержать только цифры и разделительный знак "." в формате DD.MM.YYYY', @USER, GETDATE());            
						GOTO ERROR;
					    END;
--Возможно пользователь ввел некорректный формат
IF SUBSTRING(@DATE,3,1) !='.' OR SUBSTRING(@DATE,6,1) !='.'
                        BEGIN 
						INSERT INTO #ERRORMESSAGE VALUES ('ВНИМАНИЕ! Формат даты должен быть: DD.MM.YYYY');
						INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ,1, 'Формат даты должен быть: DD.MM.YYYY', @USER, GETDATE());      
						GOTO ERROR;
					    END;

--Возможно пользователь ввел ошибочное количество дней в месяце
IF CONVERT(INT, SUBSTRING(@DATE,1,2))>31 or CONVERT(INT, SUBSTRING(@DATE,1,2))<1
                        BEGIN 
						INSERT INTO #ERRORMESSAGE VALUES ('Количество дней в месяце не может быть более 31');
						INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ,1, 'Количество дней в месяце не может быть более 31', @USER, GETDATE());      
				        GOTO ERROR;
					    END;
--Возможно пользователь ошибся при вводе количества дней в определнных месяцах
IF (CONVERT(INT, SUBSTRING(@DATE,1,2))>30 AND SUBSTRING(@DATE,4,2) IN ('04','06','09','11')) 
                        BEGIN 
						INSERT INTO #ERRORMESSAGE VALUES ('Некорректное количество дней в данном месяце('+SUBSTRING(@DATE,4,2)+')');
						INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ,1, 'Некорректное количество дней в данном месяце('+SUBSTRING(@DATE,4,2)+')', @USER, GETDATE());
						GOTO ERROR;
						END;
--Частая ошибка в феврале
IF (CONVERT(INT, SUBSTRING(@DATE,1,2))>29 AND SUBSTRING(@DATE,4,2) = '02') 
                        BEGIN 
						INSERT INTO #ERRORMESSAGE VALUES ('Некорректное количество дней в данном месяце('+SUBSTRING(@DATE,4,2)+')'); 
						INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ,1, 'Некорректное количество дней в данном месяце('+SUBSTRING(@DATE,4,2)+')', @USER, GETDATE());      
					    GOTO ERROR;
						END;
--Проверка на високосный год
IF (CONVERT(INT, SUBSTRING(@DATE,1,2))>28 AND SUBSTRING(@DATE,4,2) = '02' AND CONVERT(INT, SUBSTRING(@DATE,7,4)) % 4 <> 0) 
                        BEGIN 
						INSERT INTO #ERRORMESSAGE VALUES ('Некорректное количество дней в данном месяце('+SUBSTRING(@DATE,4,2)+') с учетом невисокосного года (' + SUBSTRING(@DATE,7,4) +')'); 
						INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ,1, 'Некорректное количество дней в данном месяце('+SUBSTRING(@DATE,4,2)+') с учетом невисокосного года (' + SUBSTRING(@DATE,7,4) +')', @USER, GETDATE());
						GOTO ERROR;
						END;
--Проверка на месяц
IF CONVERT(INT, SUBSTRING(@DATE,4,2))>12 or CONVERT(INT, SUBSTRING(@DATE,4,2)) <1
                        BEGIN 
						INSERT INTO #ERRORMESSAGE VALUES ('Некорректный месяц('+SUBSTRING(@DATE,4,2)+')'); 
						INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ,1, 'Некорректный месяц('+SUBSTRING(@DATE,4,2)+') ', @USER, GETDATE());
						GOTO ERROR;
						END;
end;
END CATCH;
END;
--ОБРАБОТКА ДИРЕКТОРИИ!
--Начинаем проверку введенных путей хранений файла
INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 0, 'ОБРАБОТКА ДИРЕКТОРИИ', @USER, GETDATE());
      IF @PATH IS NULL OR @PATH = '' OR @PATH = '-1'
--Если путь пустой, то возьмем дефолтовый
BEGIN 
--Начинаем формирование дефолтового пути + поддиректории в зависимости от входящей даты (если дата пустая, то берется текущая)
DECLARE @PATH_T NVARCHAR(300);
SELECT @PATH_T = VALUE_OUT FROM [ETL_DB].[DBO].[BANK_EXTRACT_MAIN] WHERE ID = 0;
SELECT @PATH_T  = @PATH_T + SUBSTRING(VALUE_OUT,7,4)+'\' FROM [ETL_DB].[DBO].[BANK_EXTRACT_MAIN] WHERE ID = 2;
SELECT @PATH_T = @PATH_T + VALUE_OUT + ' ' FROM [ETL_DB].[DBO].[BANK_EXTRACT_MAIN] 
       WHERE VALUE_IN = (SELECT SUBSTRING(VALUE_OUT,4,2) FROM [ETL_DB].[DBO].[BANK_EXTRACT_MAIN] WHERE ID = 2);
SELECT @PATH_T = @PATH_T + SUBSTRING(VALUE_OUT,9,2)+'\' FROM [ETL_DB].[DBO].[BANK_EXTRACT_MAIN] WHERE ID = 2;
SELECT @PATH_T = @PATH_T + SUBSTRING(VALUE_OUT,1,6) +SUBSTRING(VALUE_OUT,9,2)  FROM [ETL_DB].[DBO].[BANK_EXTRACT_MAIN] WHERE ID = 2;

UPDATE [ETL_DB].[DBO].[BANK_EXTRACT_MAIN] 
	         SET VALUE_IN = 'DEFAULT',--(SELECT VALUE_IN FROM [ETL_DB].[DBO].[BANK_EXTRACT_MAIN] WHERE ID=0), 
			 VALUE_OUT = @PATH_T--(SELECT VALUE_OUT FROM [ETL_DB].[DBO].[BANK_EXTRACT_MAIN] WHERE ID=0) 
			 WHERE ID=1;
INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ,0, 'Проставлено значение пути в управляющую таблицу', @USER, GETDATE());
--Проверяем существование данной папки
   IF OBJECT_ID(N'TEMPDB..#T0',N'U') IS NOT NULL DROP TABLE #T0
   CREATE TABLE #T0(P1 INT, P2 INT, P3 INT)
   DECLARE @OUT_ INT;
   SET @OUT_ = 0;
--Вставляем значение проверки в темповую таблицу
   INSERT #T0 EXEC MASTER..XP_FILEEXIST @PATH_T
   SELECT @OUT_ = P2 FROM #T0
     IF @OUT_ = 0 
--Если такой директории не существует, добавляем записи в таблицу ошибок 
	    BEGIN INSERT INTO #ERRORMESSAGE VALUES ('ВНИМАНИЕ! Директории '+@PATH_T+' не существует');
		INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 1,'Директория, указанная по дефолту, не существует: '+@PATH_T, @USER, GETDATE());
--И проставляем флаг не успешности проверки директории
		/*UPDATE [ETL_DB].[DBO].[BANK_EXTRACT_FLAG]
                               SET PATH_FLAG = 0;*/
INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 1,'Проставляем флаг некорректности пути', @USER, GETDATE());
GOTO ERROR
	    		END;
		ELSE
--Проставим флаг успешности проверки пути
          BEGIN 
			/* UPDATE [ETL_DB].[DBO].[BANK_EXTRACT_FLAG]
                               SET PATH_FLAG = 1;*/
INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 0,'Проставляем флаг корректности пути', @USER, GETDATE());
		   END;
INSERT INTO #MESSAGE VALUES ('Директория для загрузки выписок: '+@PATH_T);
INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 0,'Корректная директория по дефолту: '+@PATH_T, @USER, GETDATE());
		  END;
	  ELSE

--Если путь заполнен, начинаем парсинг
BEGIN
   DECLARE @PATH_LEN INT; --длина указанного пути
   DECLARE @PATH_TEMP NVARCHAR(300);--значение пользователя
   SET @PATH_TEMP = @PATH;
   SET @PATH_LEN = LEN(@PATH);
--Проверяем, наличие указанной сетевой папки в справочник путей
   IF SUBSTRING(@PATH,1,1) = 'U'
   BEGIN
   SET @PATH = SUBSTRING(@PATH,1,3) + @USER +'\' +SUBSTRING(@PATH,4,LEN(@PATH)-3); 
   END;
    SET @PATH_LEN = LEN(@PATH);
   IF SUBSTRING(@PATH,1,1) IN (SELECT VALUE_IN FROM [ETL_DB].[DBO].[BANK_EXTRACT_MAIN] WHERE NAME = 'MAP_PATH')
   
   BEGIN
--Если сетевая папка присутсвует, то проверяем что написал пользователь: если просто указад сетевой диск или полный адрес папки
--Если укахал только диск, то проставляем в переменную реальный адрес диска 
   IF @PATH_LEN < 4 SELECT @PATH = VALUE_OUT FROM [ETL_DB].[DBO].[BANK_EXTRACT_MAIN] WHERE VALUE_IN = SUBSTRING(@PATH,1,1);
--Если указал полный путь, то к реальному адресу диска добавляем адрес, указанный пользователем
   ELSE SELECT @PATH = VALUE_OUT+SUBSTRING(@PATH,4,@PATH_LEN-3) FROM [ETL_DB].[DBO].[BANK_EXTRACT_MAIN] WHERE VALUE_IN = SUBSTRING(@PATH,1,1);
--Создаем темповую таблицу для вывода резальтатов проверки пути, указанного пользователем   
   IF OBJECT_ID(N'TEMPDB..#T1',N'U') IS NOT NULL DROP TABLE #T1
   CREATE TABLE #T1(P1 INT, P2 INT, P3 INT)
   DECLARE @OUT INT;
   SET @OUT = 0;
--Вставляем значение проверки в темповую таблицу
   INSERT #T1 EXEC MASTER..XP_FILEEXIST @PATH
   SELECT @OUT = P2 FROM #T1
     IF @OUT = 0 
--Если такой директории не существует, добавляем записи в таблицу ошибок 
	    BEGIN INSERT INTO #ERRORMESSAGE VALUES ('ВНИМАНИЕ! Директории '+@PATH_TEMP+' не существует');
		INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 1,'Некорректная директория расположения файлов, указанная пользователем: '+@PATH_TEMP, @USER, GETDATE());
--И проставляем флаг не успешности проверки директории
		/*UPDATE [ETL_DB].[DBO].[BANK_EXTRACT_FLAG]
                               SET PATH_FLAG = 0;*/
		GOTO ERROR
		END;
--Если все хорошо и такая директория есть, то выводи в сообщение
	 ELSE BEGIN 
	      INSERT INTO #MESSAGE VALUES ('Директория для загрузки файлов: '+@PATH);
		  INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 0,'Корректная директория расположения файлов, указанная пользователем: '+@PATH, @USER, GETDATE());
--Проставляем путь в управляющую таблицу
	      UPDATE [ETL_DB].[DBO].[BANK_EXTRACT_MAIN] 
	      SET VALUE_IN = @PATH_TEMP,
	      VALUE_OUT = @PATH WHERE ID = 1;
--Проставляем флаг успешно проверки директории
		  /*UPDATE [ETL_DB].[DBO].[BANK_EXTRACT_FLAG]
                               SET PATH_FLAG = 1;*/
		  END;
   END;
   ELSE 
   BEGIN 
--Если не прошли первую проверку, то не настроен мэппинг сетевых диско в справочной таблицу
   INSERT INTO #ERRORMESSAGE VALUES ('ВНИМАНИЕ! Должна быть указана сетевая папка на дисках S, T, X, R, G, H, M');
   INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 1,'Введен некорректный путь. Отсутствует название доступного сетевого диска или не хватает прав на доступ к папке.', @USER, GETDATE());
--Проставляем флаг не успешности проверки директории   
   /*UPDATE [ETL_DB].[DBO].[BANK_EXTRACT_FLAG]
                               SET PATH_FLAG = 0;*/
	GOTO ERROR
	 END;

  END;
  --ОБРАБОТКА ПАРТНЕРОВ
  INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 0, 'ОБРАБОТКА ПАРТНЕРА', @USER, GETDATE());
  BEGIN TRY
  IF @CONTRACT IS NULL OR @CONTRACT = '' OR @CONTRACT = '-1'
     BEGIN
     UPDATE 
          [ETL_DB]..[BANK_EXTRACT_MAIN]
		  SET VALUE_OUT = '1'
		  WHERE NAME = 'PARTNER_FLAG';
	 INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 0, 'Выбраны все партнеры. Проставлены соответствующие флаги.', @USER, GETDATE());
	 END;
   ELSE 
     BEGIN
	  UPDATE 
          [ETL_DB]..[BANK_EXTRACT_MAIN]
		  SET VALUE_OUT = '0'
		  WHERE NAME = 'PARTNER_FLAG';
	    IF CONVERT(NVARCHAR, @CONTRACT) NOT IN (SELECT VALUE_IN FROM [ETL_DB]..[BANK_EXTRACT_MAIN] WHERE NAME = 'PARTNER_NAME')
		   BEGIN 
		   INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 1, 'Отсутствует код партнера: '+CONVERT(NVARCHAR, @CONTRACT)+' в справочнике.', @USER, GETDATE());    
		   INSERT INTO #ERRORMESSAGE VALUES ('ВНИМАНИЕ! Отсутствует код партнера в справочнике. Выгрузка невозможна.');
		   GOTO ERROR
		   END;  
		ELSE 
		   BEGIN
		   DECLARE @NAME VARCHAR(20);
		   SELECT @NAME = VALUE_OUT FROM [ETL_DB]..[BANK_EXTRACT_MAIN] WHERE NAME = 'PARTNER_NAME' AND VALUE_IN = CONVERT(NVARCHAR, @CONTRACT);
		   UPDATE [ETL_DB]..[BANK_EXTRACT_MAIN] SET VALUE_OUT = '1' WHERE VALUE_IN = @CONTRACT AND NAME = 'PARTNER_FLAG';
		   INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 0, 'Выбран партнер с кодом: '+CONVERT(NVARCHAR, @CONTRACT)+'('+@NAME+'), проставлен флаг в управляющей таблице.', @USER, GETDATE());    
		   INSERT INTO #MESSAGE VALUES ('Выбран партнер с кодом: '+CONVERT(NVARCHAR, @CONTRACT)+'('+@NAME+').');    
		   END;  
	 END;
	 END TRY
	 BEGIN CATCH
	 BEGIN
	 INSERT INTO #ERRORMESSAGE VALUES ('ВНИМАНИЕ! Отсутствует код партнера в справочнике. Выгрузка невозможна.');
	 INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 1, 'Невозможно сконвертировать код партнера. Значения могут быть только из справочника.', @USER, GETDATE());    
	 GOTO ERROR
	 END;
	 END CATCH
--ОБРАБОТКА НАЗВАНИЯ ФАЙЛА ПАРТНЕРА
INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 0, 'ОБРАБОТКА ФАЙЛА', @USER, GETDATE());
--Обнуляем значения управляющей таблицы
UPDATE [ETL_DB]..[BANK_EXTRACT_MAIN] SET VALUE_OUT = NULL WHERE NAME LIKE 'PARTNER_FILE_REAL%';
DECLARE @FILE VARCHAR(100);
DECLARE @FCOUNT INT;
DECLARE @PID VARCHAR(1);
--Создаем таблицу для заполнения значения файлов, расположенных в искомой папке
 IF OBJECT_ID(N'TEMPDB..#TF1',N'U') IS NOT NULL DROP TABLE #TF1
   CREATE TABLE #TF1(FILE_NAME VARCHAR(100))
   SELECT @PATH = 'DIR /b "'+VALUE_OUT+'\"' FROM [BANK_EXTRACT_MAIN] WHERE ID = 1;
--Вставляем значение проверки в темповую таблицу
   INSERT #TF1 EXEC MASTER..XP_CMDSHELL @PATH;
   DELETE FROM #TF1 WHERE FILE_NAME IS NULL
--Все логируем!
IF  (SELECT count(*) FROM #TF1) = 0
  BEGIN
  INSERT INTO #ERRORMESSAGE VALUES ('В указанной директории нет ни одного файла.')
  INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 1, 'В папке нет ни одного файла! Указанная директория: '+SUBSTRING(@PATH,8,100), @USER, GETDATE());
  GOTO ERROR
  END;
INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 0, 'В папке присутствуют файлы (в количестве: '+(SELECT CONVERT(VARCHAR, count(*)) FROM #TF1)+')', @USER, GETDATE());
--INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 0, (SELECT FILE_NAME FROM #TF1), @USER, GETDATE());
--Создаем темповую таблицу для обработки файлов по контракту
IF OBJECT_ID(N'TEMPDB..#TFILE',N'U') IS NOT NULL DROP TABLE #TFILE;
CREATE TABLE #TFILE(ID INT, FILE_MASK VARCHAR(50), FLAG INT);
--Вставляем данные в темповую таблицу, где проставлен флаг выборки контракта
INSERT INTO #TFILE SELECT VALUE_IN, VALUE_OUT, 1 FROM [ETL_DB]..[BANK_EXTRACT_MAIN] 
                               WHERE NAME = 'PARTNER_FILE' AND VALUE_IN IN 
    					        (SELECT VALUE_IN FROM [ETL_DB]..[BANK_EXTRACT_MAIN] 
							   	  WHERE NAME = 'PARTNER_FLAG' AND VALUE_OUT = '1');
SELECT @FCOUNT = COUNT(*) FROM #TFILE;
INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 0, 'Количество контрактов, добавленных на обработку: '+CONVERT(VARCHAR, @FCOUNT), @USER, GETDATE());
   --Выбираем данные из темповой таблицы для обработки
WHILE  (SELECT COUNT(FILE_MASK) FROM #TFILE WHERE FLAG = 1)>0 AND (SELECT COUNT(*) FROM #ERRORMESSAGE)=0
BEGIN
SELECT TOP 1 @FILE =FILE_MASK, @PID = CONVERT(VARCHAR, ID) FROM #TFILE WHERE FLAG = 1;
 UPDATE #TFILE SET FLAG = 0 WHERE ID = CONVERT(INT, @PID);
 INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 0, 'Обработка файла контракта ID =  '+@PID+' с маской: '+@FILE, @USER, GETDATE());
 IF (SELECT count(FILE_NAME) FROM #TF1 WHERE FILE_NAME LIKE '%'+@FILE+'%')=1
    BEGIN 
	UPDATE [ETL_DB]..[BANK_EXTRACT_MAIN] SET VALUE_OUT = (SELECT FILE_NAME FROM #TF1 WHERE FILE_NAME LIKE '%'+@FILE+'%') 
	      WHERE NAME = 'PARTNER_FILE_REAL' AND VALUE_IN = @PID;
    INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 0, 'Найден файл контракта ID =  '+@PID+' :'+(SELECT FILE_NAME FROM #TF1 WHERE FILE_NAME LIKE '%'+@FILE+'%'), @USER, GETDATE());
	INSERT INTO #MESSAGE VALUES ('Найден файл контракта ID =  '+@PID+' :'+(SELECT FILE_NAME FROM #TF1 WHERE FILE_NAME LIKE '%'+@FILE+'%'));
	END;
 ELSE 
    BEGIN
	IF (SELECT count(FILE_NAME) FROM #TF1 WHERE FILE_NAME LIKE '%'+@FILE+'%')=0
	BEGIN
	INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 2, 'Файл контракта ID =  '+@PID+' : '+' не найден. Маска поиска: '+ @FILE, @USER, GETDATE());
	INSERT INTO #WARMESSAGE VALUES ('Внимание! Файл контракта ID =  '+@PID+' : '+' не найден. Маска поиска: '+ @FILE);
	END;
	ELSE
	INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 2, 'Файлов больше 1. Файл контракта ID =  '+@PID+' : '+'. Маска поиска: '+ @FILE, @USER, GETDATE());
	    WHILE (SELECT count(FILE_NAME) FROM #TF1 WHERE FILE_NAME LIKE '%'+@FILE+'%')>0
	    BEGIN
		DECLARE @TEMPFILENAME VARCHAR(100)
		SELECT TOP 1 @TEMPFILENAME = FILE_NAME FROM #TF1 WHERE FILE_NAME LIKE '%'+@FILE+'%';
		IF (SELECT VALUE_OUT FROM [ETL_DB]..[BANK_EXTRACT_MAIN] WHERE NAME = 'PARTNER_FILE_REAL' AND VALUE_IN = @PID) IS NULL
		   BEGIN
		    UPDATE [ETL_DB]..[BANK_EXTRACT_MAIN] SET VALUE_OUT = @TEMPFILENAME
	         WHERE NAME = 'PARTNER_FILE_REAL' AND VALUE_IN = @PID;
            INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 0, 'Найден файл контракта ID =  '+@PID+' :'+@TEMPFILENAME, @USER, GETDATE());
		    INSERT INTO #MESSAGE VALUES ('Найден файл контракта ID =  '+@PID+' :'+@TEMPFILENAME);
		   END;
	     ELSE 
		    BEGIN
			  IF (SELECT VALUE_OUT FROM [ETL_DB]..[BANK_EXTRACT_MAIN] WHERE NAME = 'PARTNER_FILE_REAL_2' AND VALUE_IN = @PID) IS NULL
		          BEGIN
		          UPDATE [ETL_DB]..[BANK_EXTRACT_MAIN] SET VALUE_OUT = @TEMPFILENAME
	               WHERE NAME = 'PARTNER_FILE_REAL_2' AND VALUE_IN = @PID;
                  INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 0, 'Найден файл контракта ID =  '+@PID+' :'+@TEMPFILENAME, @USER, GETDATE());
		          INSERT INTO #MESSAGE VALUES ('Найден файл контракта ID =  '+@PID+' :'+@TEMPFILENAME);
				  END;
			  ELSE
			  BEGIN
			     IF (SELECT VALUE_OUT FROM [ETL_DB]..[BANK_EXTRACT_MAIN] WHERE NAME = 'PARTNER_FILE_REAL_3' AND VALUE_IN = @PID) IS NULL
		             BEGIN
		             UPDATE [ETL_DB]..[BANK_EXTRACT_MAIN] SET VALUE_OUT = @TEMPFILENAME
	                   WHERE NAME = 'PARTNER_FILE_REAL_3' AND VALUE_IN = @PID;
                     INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 0, 'Найден файл контракта ID =  '+@PID+' :'+@TEMPFILENAME, @USER, GETDATE());
		             INSERT INTO #MESSAGE VALUES ('Найден файл контракта ID =  '+@PID+' :'+@TEMPFILENAME);
					 END;
				  ELSE
				  BEGIN
			           IF (SELECT VALUE_OUT FROM [ETL_DB]..[BANK_EXTRACT_MAIN] WHERE NAME = 'PARTNER_FILE_REAL_4' AND VALUE_IN = @PID) IS NULL
		                   BEGIN
		                   UPDATE [ETL_DB]..[BANK_EXTRACT_MAIN] SET VALUE_OUT = @TEMPFILENAME
	                        WHERE NAME = 'PARTNER_FILE_REAL_4' AND VALUE_IN = @PID;
                           INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 0, 'Найден файл контракта ID =  '+@PID+' :'+@TEMPFILENAME, @USER, GETDATE());
		                   INSERT INTO #MESSAGE VALUES ('Найден файл контракта ID =  '+@PID+' :'+@TEMPFILENAME);
						   END;	
					   ELSE
					   BEGIN
			                IF (SELECT VALUE_OUT FROM [ETL_DB]..[BANK_EXTRACT_MAIN] WHERE NAME = 'PARTNER_FILE_REAL_5' AND VALUE_IN = @PID) IS NULL
		                       BEGIN
		                       UPDATE [ETL_DB]..[BANK_EXTRACT_MAIN] SET VALUE_OUT = @TEMPFILENAME
	                            WHERE NAME = 'PARTNER_FILE_REAL_5' AND VALUE_IN = @PID;
                               INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 0, 'Найден файл контракта ID =  '+@PID+' :'+@TEMPFILENAME, @USER, GETDATE());
		                       INSERT INTO #MESSAGE VALUES ('Найден файл контракта ID =  '+@PID+' :'+@TEMPFILENAME);
							   END;
					   END		     
				  END
			  END
			END  
			DELETE  FROM #TF1 WHERE FILE_NAME = @TEMPFILENAME;
		END
 END; 


 END;
 
 
--Проверяем файлы и если нет ни одного, то выходим из процедуры и репортуем ошибку
IF (SELECT COUNT(*) FROM BANK_extract_main where name like 'PARTNER_FILE_REAL%' AND VALUE_OUT IS NOT NULL) = 0 
BEGIN
INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 1,'ОШИБКА! Не найдено ни одного файла по заданным критериям!', @USER, GETDATE());
INSERT INTO #ERRORMESSAGE VALUES ('ОШИБКА! Не найденого ни одного файла по заданным критериям.');
GOTO ERROR
END;

--Логируем исполняемую команду
INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG]
SELECT @SEQ, 0, 
'Команда запуска: PROC_BANK_EXTRACT ''' + 
ED.VALUE_OUT+'''' +', '''+
PF.VALUE_IN + ''', '''+ 
CONVERT(VARCHAR, COUNT(FL.VALUE_IN))+''', '''+
EU.VALUE_OUT+'''',
@USER,
GETDATE()
FROM BANK_EXTRACT_MAIN PF 
JOIN BANK_EXTRACT_MAIN ED ON ED.NAME = 'EXTRACT_DATE'
JOIN BANK_EXTRACT_MAIN EU ON EU.NAME = 'USER'
JOIN BANK_EXTRACT_MAIN FL ON FL.NAME = 'PARTNER_FLAG' AND FL.VALUE_OUT <>0
WHERE PF.NAME='PATH_FULL'
GROUP BY ED.VALUE_OUT, PF.VALUE_IN, EU.VALUE_OUT, 
FL.VALUE_OUT

--Запуск SSIS пакета
INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 0,'SSIS: Запуск SSIS пакета.', @USER, GETDATE());
TRUNCATE TABLE BANK_EXTRACT_SSIS_LOG;
insert BANK_EXTRACT_SSIS_LOG
exec xp_cmdshell 'cd.. && "E:\Program Files\Microsoft SQL Server\120\DTS\Binn\DTExec.exe"  /DECRYPT Aiglife1 /F "D:\11.09_BANK_EXTRACT\11.09_BANK_EXTRACT\1_BANK_EXTRACT.dtsx" /Rep V'


IF EXISTS (
select * 
FROM BANK_EXTRACT_SSIS_LOG 
WHERE 
    LOG LIKE '%DTSER_FAILURE%' )
	BEGIN
	INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] SELECT @SEQ, 1, 
     LTRIM(RTRIM(LOG)), @USER, GETDATE()
     FROM BANK_EXTRACT_SSIS_LOG WHERE
     LOG LIKE '%FAIL%';
	 INSERT INTO #ERRORMESSAGE VALUES ('ВНИМАНИЕ! SSIS пакет завершился с ошибками!');
	 GOTO ERROR 
	END

INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 0,'SSIS: Загрузка данных во временные таблицы:', @USER, GETDATE());
INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] 
SELECT @SEQ, 0, 
     'SSIS: '+REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(LOG)), 'Description','Шаг'), 'wrote', 'записал'), 'rows.','строк')+' во временную таблицу.', @USER, GETDATE()
FROM BANK_EXTRACT_SSIS_LOG 
WHERE 
    LOG LIKE '%wrote%' 
	AND
	LOG like '%_EXTRACT_%';

INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 0,'SSIS: Загрузка данных в продуктовую таблицу:', @USER, GETDATE());
INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] 
SELECT @SEQ, 0, 
     'SSIS: '+REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(LOG)), 'Description','Шаг'), 'wrote', 'записал'), 'rows.','строк')+' в продуктовую таблицу.', @USER, GETDATE()
FROM BANK_EXTRACT_SSIS_LOG 
WHERE 
    LOG LIKE '%wrote%' 
	AND
	LOG like '%_PROD%'
	AND
	LOG NOT LIKE '%SHIFT%'
UNION 
SELECT @SEQ, 0, 
     'SSIS: '+REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(LOG)), 'Description','Шаг'), 'wrote', 'записал'), 'rows.','строк')+' в таблицу ошибок сдвига.', @USER, GETDATE()
FROM BANK_EXTRACT_SSIS_LOG 
WHERE 
    LOG LIKE '%wrote%' 
	AND
	LOG like '%_PROD_SHIFT%';
IF EXISTS (SELECT * FROM [ETL_DB]..[BANK_STATEMENT_ERR])
INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] 
SELECT @SEQ, 0, 
     'SSIS записал в таблицу ошибок: '+ CONVERT(VARCHAR, COUNT(*)) + ' записей.', @USER, GETDATE()
FROM [ETL_DB]..[BANK_STATEMENT_ERR] 
	

INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 0,'SSIS: Пакет завершил работу. Логи работы пакета: BANK_EXTRACT_SSIS_LOG', @USER, GETDATE());

INSERT INTO #MESSAGE
SELECT 
     'Пакет: ' + LTRIM(RTRIM(LOG))
FROM BANK_EXTRACT_SSIS_LOG 
WHERE 
    LOG LIKE '%wrote%' 
	AND
	LOG like '%_PROD%';

IF EXISTS (SELECT * FROM [ETL_DB]..[BANK_STATEMENT_ERR])
INSERT INTO #MESSAGE
SELECT 
     'Пакет записал в таблицу ошибок: ' + CONVERT(VARCHAR, COUNT(*)) + ' записей'
FROM [ETL_DB]..[BANK_STATEMENT_ERR];


INSERT INTO #MESSAGE VALUES ('Пакет: SSIS пакет отработал.');

--Запускаем процедуру обработки сдвинутых строк для CITI
IF (SELECT VALUE_OUT FROM BANK_EXTRACT_MAIN WHERE NAME = 'PARTNER_FLAG' AND VALUE_IN='1')='1' 
    AND (SELECT COUNT(*) FROM BANK_EXTRACT_MAIN WHERE NAME LIKE 'PARTNER_FILE_REAL%' AND VALUE_IN='1' AND VALUE_OUT IS NOT NULL)>0
	AND (SELECT COUNT(*) FROM BANK_STATEMENT_HST_SHIFT)>0

BEGIN
INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 0,'Запуск процедуры обработки сдвинутых строк для CITI.', @USER, GETDATE());
exec [ETL_DB]..[PROC_BANK_EXTRACT_SHIFT];
IF @@ERROR<>0 INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 0,'ОШИБКИ в процедуре обработки сдвинутых строк для CITI.', @USER, GETDATE());
INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 0,'Завершение процедуры обработки сдвинутых строк для CITI.', @USER, GETDATE());
END;

---Подсчет количества загруженных данных

SELECT 
     @FULLCOUNT = SUM(CASE WHEN ISNUMERIC(SUBSTRING(LTRIM(RTRIM(LOG)), CHARINDEX('wrote', LTRIM(RTRIM(LOG)))+6, CHARINDEX('rows', LTRIM(RTRIM(LOG)))-CHARINDEX('wrote', LTRIM(RTRIM(LOG)))-6))=0 THEN NULL ELSE
	 CONVERT(INT, SUBSTRING(LTRIM(RTRIM(LOG)), CHARINDEX('wrote', LTRIM(RTRIM(LOG)))+6, CHARINDEX('rows', LTRIM(RTRIM(LOG)))-CHARINDEX('wrote', LTRIM(RTRIM(LOG)))-6)) END) 
FROM BANK_EXTRACT_SSIS_LOG 
WHERE 
    LOG LIKE '%wrote%' 
	AND
	LOG like '%_PROD%'
	AND
	LOG NOT like '%_PROD_SHIFT%';



IF (SELECT SUM(CONVERT(INT, SUBSTRING(MESSAGE, CHARINDEX(': ', MESSAGE)+2, CHARINDEX(' записей', MESSAGE)-CHARINDEX(': ', MESSAGE)-2)))
FROM BANK_EXTRACT_LOG WHERE ID =
(SELECT CURRENT_VALUE FROM SYS.sequences WHERE NAME = 'SEQ_BANK_EXTRACT_LOG')
AND MESSAGE LIKE 'Процедура сдвига%') IS NOT NULL
BEGIN 
SELECT @FULLCOUNT = @FULLCOUNT + 
SUM(CONVERT(INT, SUBSTRING(MESSAGE, CHARINDEX(': ', MESSAGE)+2, CHARINDEX(' записей', MESSAGE)-CHARINDEX(': ', MESSAGE)-2)))
FROM BANK_EXTRACT_LOG WHERE ID =
(SELECT CURRENT_VALUE FROM SYS.sequences WHERE NAME = 'SEQ_BANK_EXTRACT_LOG')
AND MESSAGE LIKE 'Процедура сдвига%';
END;

INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 0,'Общее количество добавленных строк:'+convert(varchar, @fullcount), @USER, GETDATE());
INSERT INTO #MESSAGE VALUES ('Общее количество добавленных строк:'+convert(varchar, @fullcount));

IF ISDATE(@DATE)=1 BEGIN 
INSERT INTO [ETL_DB]..[BANK_STATEMENT_LOG] VALUES (@SEQ, CONVERT(DATETIME, GETDATE(),104), CONVERT(DATE, @DATE, 104), 1, @FULLCOUNT);
END;
ELSE BEGIN
INSERT INTO [ETL_DB]..[BANK_STATEMENT_LOG] VALUES (@SEQ, CONVERT(DATETIME, GETDATE(),104), CONVERT(DATE, @DATE, 104), 1, @FULLCOUNT);
END;

IF NOT EXISTS (SELECT * FROM #ERRORMESSAGE) 
SELECT * FROM #MESSAGE
UNION
SELECT * FROM #WARMESSAGE
UNION
SELECT 'Процедура УСПЕШНО завершена!';
INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 0,'Процедура УСПЕШНО завершена!', @USER, GETDATE());

--Запуск SSIS пакета перекачки данных на сервер Cognos
--INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 0,'Запуск репликации данных на сервер Cognos.', @USER, GETDATE());
exec xp_cmdshell 'cd.. && "E:\Program Files\Microsoft SQL Server\120\DTS\Binn\DTExec.exe"  /DECRYPT Aiglife1 /F "D:\11.09_BANK_EXTRACT\11.09_BANK_EXTRACT\2_BANK_EXTRACT_CGS.dtsx" /Rep V', no_output;
INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 0,'Репликация успешно завершена.', @USER, GETDATE());

--Блок вывода информации об ошибках и выход из процедуры
ERROR:

IF EXISTS (SELECT * FROM #ERRORMESSAGE) 
BEGIN
--Запуск SSIS пакета перекачки данных на сервер Cognos
INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 0,'Запуск репликации данных на сервер Cognos.', @USER, GETDATE());
exec xp_cmdshell 'cd.. && "E:\Program Files\Microsoft SQL Server\120\DTS\Binn\DTExec.exe"  /DECRYPT Aiglife1 /F "D:\11.09_BANK_EXTRACT\11.09_BANK_EXTRACT\2_BANK_EXTRACT_CGS.dtsx" /Rep V', no_output;
INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 0,'Репликация успешно завершена.', @USER, GETDATE());

SELECT * FROM #ERRORMESSAGE;
SET LANGUAGE RUSSIAN;
IF ISDATE(@DATE)=1 BEGIN 
INSERT INTO [ETL_DB]..[BANK_STATEMENT_LOG] VALUES (@SEQ, CONVERT(DATETIME, GETDATE(),104), CONVERT(DATE, @DATE, 104), 0, @FULLCOUNT);
END;
ELSE 
BEGIN 
INSERT INTO [ETL_DB]..[BANK_STATEMENT_LOG] VALUES (@SEQ, CONVERT(DATETIME, GETDATE(),104), CONVERT(DATE, GETDATE(), 104), 0, @FULLCOUNT);
END;
INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQ, 1,'Процедура завершена с ОШИБКАМИ!', @USER, GETDATE());
RETURN;
END;
END


