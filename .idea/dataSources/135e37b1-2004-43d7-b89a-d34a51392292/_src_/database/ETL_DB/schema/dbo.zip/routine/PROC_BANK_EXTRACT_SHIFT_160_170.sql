




CREATE PROCEDURE [dbo].[PROC_BANK_EXTRACT_SHIFT_160_170]
AS
BEGIN

--Проставляем язык русский для корректной проверки даты функцией ISDATE

--Дропаем временную таблицу сдвига
IF EXISTS (SELECT * FROM SYS.sysobjects WHERE NAME = 'BANK_EXTRACT_SHIFT_2') DROP TABLE BANK_EXTRACT_SHIFT_2;
--Создаем временную таблицу сдвига для строк со сдвигом в колонке ADD_INFO - 88
--IF EXISTS (SELECT * FROM SYS.sysobjects WHERE NAME = 'BANK_EXTRACT_SHIFT_160_170_ERROR') DROP TABLE BANK_EXTRACT_SHIFT_160_170_ERROR;
--CREATE TABLE BANK_EXTRACT_SHIFT_160_170_ERROR (ERROR INT, SEQ INT, QUERY VARCHAR(3000));
IF EXISTS (SELECT * FROM SYS.sysobjects WHERE NAME = 'BANK_EXTRACT_SHIFT_2') DROP TABLE BANK_EXTRACT_SHIFT_2;
CREATE TABLE [dbo].[BANK_EXTRACT_SHIFT_2](
	[SEQ] [bigint] NOT NULL,
	[ID] [bigint] NULL,
	[PARTNER_ID] [int] NOT NULL,
	[LOAD_DTE] [date] NULL,
	[Column 0] [date] NULL,
	[Column 1] [varchar](57) NULL,
	[Column 2] [varchar](300) NULL,
	[Column 3] [varchar](35) NULL,
	[Column 4] [varchar](25) NULL,
	[Column 5] [decimal](22, 2) NULL,
	[Column 6] [varchar](16) NULL,
	[Column 7] [varchar](105) NULL,
	[Column 8] [varchar](16) NULL,
	[Column 9] [datetime] NULL,
	[Column 10] [int] NULL,
	[Column 11] [varchar](5) NULL,
	[Column 12] [decimal](22, 2) NULL,
	[Column 13] [varchar](300) NULL,
	[Column 14] [varchar](35) NULL,
	[Column 15] [varchar](300) NULL,
	[Column 16] [varchar](3) NULL,
	[Column 17] [date] NULL,
	[Column 18] [varchar](50) NULL,
	[Column 19] [varchar](16) NULL,
	[Column 20] [varchar](16) NULL,
	[Column 21] [varchar](1000) NULL,
	[Column 22] [int] NULL,
	[Column 23] [varchar](300) NULL,
	[Column 24] [varchar](35) NULL,
	[Column 25] [varchar](50) NULL,
	[Column 26] [varchar](70) NULL,
	[Column 27] [varchar](35) NULL,
	[Column 28] [varchar](35) NULL,
	[Column 29] [varchar](70) NULL,
	[Column 30] [varchar](105) NULL,
	[Column 31] [varchar](300) NULL,
	[Column 32] [varchar](300) NULL,
	[Column 33] [varchar](300) NULL,
	[Column 34] [varchar](300) NULL,
	[Column 35] [varchar](300) NULL,
	[Column 36] [varchar](300) NULL,
	[Column 37] [varchar](105) NULL,
	[Column 38] [varchar](105) NULL,
	[Column 39] [varchar](105) NULL,
	[Column 40] [varchar](105) NULL,
	[Column 41] [varchar](140) NULL,
	[Column 42] [varchar](105) NULL,
	[Column 43] [varchar](105) NULL,
	[Column 44] [varchar](105) NULL,
	[Column 45] [varchar](105) NULL,
	[Column 46] [varchar](105) NULL,
	[Column 47] [varchar](105) NULL,
	[Column 48] [varchar](105) NULL,
	[Column 49] [varchar](105) NULL,
	[Column 50] [varchar](105) NULL,
	[Column 51] [varchar](105) NULL,
	[Column 52] [varchar](105) NULL,
	[Column 53] [varchar](105) NULL,
	[Column 54] [varchar](105) NULL,
	[Column 55] [varchar](105) NULL,
	[Column 56] [varchar](300) NULL,
	[Column 57] [varchar](35) NULL,
	[Column 58] [varchar](3) NULL,
	[Column 59] [varchar](3) NULL,
	[Column 60] [varchar](3) NULL,
	[Column 61] [varchar](3) NULL,
	[Column 62] [varchar](3) NULL,
	[Column 63] [varchar](3) NULL,
	[Column 64] [varchar](3) NULL,
	[Column 65] [varchar](3) NULL,
	[Column 66] [varchar](3) NULL,
	[Column 67] [varchar](3) NULL,
	[Column 68] [date] NULL,
	[Column 69] [date] NULL,
	[Column 70] [date] NULL,
	[Column 71] [decimal](22, 4) NULL,
	[Column 72] [varchar](16) NULL,
	[Column 73] [decimal](22, 2) NULL,
	[Column 74] [varchar](2000) NULL,
	[Column 75] [date] NULL,
	[Column 76] [date] NULL,
	[Column 77] [date] NULL,
	[Column 78] [varchar](12) NULL,
	[Column 79] [date] NULL,
	[Column 80] [date] NULL,
	[Column 81] [date] NULL,
	[Column 82] [date] NULL,
	[Column 83] [datetime] NULL,
	[Column 84] [decimal](22, 2) NULL,
	[Column 85] [decimal](22, 2) NULL,
	[Column 86] [varchar](210) NULL,
	[Column 87] [varchar](1000) NULL,
	[Column 88] [varchar](1000) NULL,
	[Column 89] [varchar](1000) NULL,
	[Column 90] [varchar](1000) NULL,
	[Column 91] [varchar](1000) NULL,
	[Column 92] [varchar](1000) NULL,
	[Column 93] [varchar](1000) NULL,
	[Column 94] [varchar](1000) NULL,
	[Column 95] [varchar](1000) NULL,
	[Column 96] [varchar](1000) NULL,
	[Column 97] [varchar](1000) NULL,
	[Column 98] [varchar](1000) NULL,
	[Column 99] [varchar](1000) NULL,
	[Column 100] [varchar](1000) NULL,
	[Column 101] [varchar](1000) NULL,
	[Column 102] [varchar](1000) NULL,
	[Column 103] [varchar](1000) NULL,
	[Column 104] [varchar](1000) NULL,
	[Column 105] [varchar](1000) NULL,
	[Column 106] [varchar](1000) NULL,
	[Column 107] [varchar](1000) NULL,
	[Column 108] [varchar](1000) NULL,
	[Column 109] [varchar](1000) NULL,
	[Column 110] [varchar](1000) NULL,
	[Column 111] [varchar](1000) NULL,
	[Column 112] [varchar](1000) NULL,
	[Column 113] [varchar](1000) NULL,
	[Column 114] [varchar](1000) NULL,
	[Column 115] [varchar](1000) NULL,
	[Column 116] [varchar](1000) NULL,
	[Column 117] [varchar](1000) NULL,
	[Column 118] [varchar](1000) NULL,
	[Column 119] [varchar](1000) NULL,
	[Column 120] [varchar](1000) NULL,
	[Column 121] [varchar](1000) NULL,
	[Column 122] [varchar](1000) NULL,
	[Column 123] [varchar](1000) NULL,
	[Column 124] [varchar](1000) NULL,
	[Column 125] [varchar](1000) NULL,
	[Column 126] [varchar](1000) NULL,
	[Column 127] [varchar](1000) NULL,
	[Column 128] [varchar](1000) NULL,
	[Column 129] [varchar](1000) NULL,
	[Column 130] [varchar](1000) NULL,
	[Column 131] [varchar](1000) NULL,
	[Column 132] [varchar](1000) NULL,
	[Column 133] [varchar](1000) NULL,
	[Column 134] [varchar](1000) NULL,
	[Column 135] [varchar](1000) NULL,
	[Column 136] [varchar](1000) NULL,
	[Column 137] [varchar](1000) NULL,
	[Column 138] [varchar](1000) NULL,
	[Column 139] [varchar](1000) NULL,
	[Column 140] [varchar](1000) NULL,
	[Column 141] [varchar](1000) NULL,
	[Column 142] [varchar](1000) NULL,
	[Column 143] [varchar](1000) NULL,
	[Column 144] [varchar](1000) NULL,
	[Column 145] [varchar](1000) NULL,
	[Column 146] [varchar](1000) NULL,
	[Column 147] [varchar](1000) NULL,
	[Column 148] [varchar](1000) NULL,
	[Column 149] [varchar](1000) NULL,
	[Column 150] [varchar](1000) NULL,
	[Column 151] [varchar](1000) NULL,
	[Column 152] [varchar](1000) NULL,
	[Column 153] [varchar](1000) NULL,
	[Column 154] [varchar](1000) NULL,
	[Column 155] [varchar](1000) NULL,
	[Column 156] [varchar](1000) NULL,
	[Column 157] [varchar](1000) NULL,
	[Column 158] [varchar](1000) NULL,
	[Column 159] [varchar](1000) NULL,
	[Column 160] [varchar](3000) NULL,
	[Column 161] [varchar](1000) NULL,
	[Column 162] [varchar](2000) NULL,
	[Column 163] [varchar](1000) NULL,
	[Column 164] [varchar](1000) NULL,
	[Column 165] [varchar](1000) NULL,
	[Column 166] [varchar](1000) NULL,
	[Column 167] [varchar](1000) NULL,
	[Column 168] [varchar](1000) NULL,
	[Column 169] [varchar](1000) NULL,
	[Column 170] [varchar](1000) NULL,
	[Column 171] [varchar](1000) NULL,
	[Column 172] [varchar](1000) NULL,
	[Column 173] [varchar](1000) NULL,
	[Column 174] [varchar](1000) NULL,
	[Column 175] [varchar](1000) NULL,
	[Column 176] [varchar](1000) NULL,
	[Column 177] [varchar](1000) NULL,
	[Column 178] [varchar](1000) NULL,
	[Column 179] [varchar](1000) NULL,
	[Column 180] [varchar](1000) NULL,
	[Column 181] [varchar](1000) NULL,
	[Column 182] [varchar](1000) NULL,
	[Column 183] [varchar](1000) NULL,
	[Column 184] [varchar](1000) NULL,
	[Column 185] [varchar](1000) NULL,
	[Column 186] [varchar](1000) NULL,
	[Column 187] [varchar](1000) NULL,
	[Column 188] [varchar](1000) NULL,
	[Column 189] [varchar](1000) NULL,
	[Column 190] [varchar](1000) NULL,
	[Column 191] [varchar](1000) NULL,
	[Column 192] [varchar](1000) NULL,
	[Column 193] [varchar](1000) NULL,
	[Column 194] [varchar](1000) NULL,
	[Column 195] [varchar](1000) NULL,
	[Column 196] [varchar](1000) NULL,
	[Column 197] [varchar](1000) NULL,
	[Column 198] [varchar](1000) NULL,
	[Column 199] [varchar](1000) NULL,
	[Column 200] [varchar](1000) NULL,
	[Column 201] [varchar](1000) NULL,
	[Column 202] [varchar](1000) NULL,
	[Column 203] [varchar](1000) NULL,
	[Column 204] [varchar](1000) NULL,
	[Column 205] [varchar](1000) NULL,
	[Column 206] [varchar](1000) NULL,
	[Column 207] [varchar](1000) NULL,
	[Column 208] [varchar](1000) NULL,
	[Column 209] [varchar](1000) NULL,
	[Column 210] [varchar](1000) NULL,
	[Column 211] [varchar](1000) NULL,
	[Column 212] [varchar](1000) NULL,
	[Column 213] [varchar](1000) NULL,
	[Column 214] [varchar](1000) NULL,
	[Column 215] [varchar](1000) NULL,
	[Column 216] [varchar](1000) NULL,
	[Column 217] [varchar](1000) NULL,
	[Column 218] [varchar](1000) NULL,
	[Column 219] [varchar](1000) NULL,
	[Column 220] [varchar](1000) NULL,
	[Column 221] [varchar](1000) NULL,
	[Column 222] [varchar](1000) NULL,
	[Column 223] [varchar](1000) NULL,
	[Column 224] [varchar](1000) NULL,
	[Column 225] [varchar](1000) NULL,
	[Column 226] [varchar](1000) NULL,
	[Column 227] [varchar](1000) NULL,
	[Column 228] [varchar](1000) NULL,
	[Column 229] [varchar](1000) NULL,
	[Column 230] [varchar](1000) NULL,
	[Column 231] [varchar](1000) NULL,
	[Column 232] [varchar](1000) NULL,
	[Column 233] [varchar](1000) NULL,
	[SHIFT_COUNT] [int] NULL,
	[COLUMN 234] [varchar](1000) NULL,
	[SHIFT_COUNT2] [int] NULL);

INSERT INTO BANK_EXTRACT_SHIFT_2 
SELECT 
       NEXT VALUE FOR [dbo].[SEQ_BANK_EXTRACT_SHIFT] AS SEQ,
	   [ID] AS [ID],
	   1 AS [PARTNER_ID], 
       CONVERT(DATE, GETDATE()) AS [LOAD_DTE], 
	   
	   CASE WHEN ISDATE([Column 0])=0 THEN NULL ELSE 
	   CONVERT(DATE, [Column 0]) END --AS [CONTRACT_DATE]
	   AS [Column 0]
      ,[Column 1] --AS [ADD_REQUISITE]
      ,[Column 2] --AS [BENF_ID_CODE]
      ,[Column 3] --AS [BENF_ID_CODE_TYPE]
      ,[Column 4] --AS [CODE_UIN_UIP]

      ,CASE WHEN ISNUMERIC(REPLACE(REPLACE(REPLACE([Column 5], ',',''), '(','-'),')','')) = 0 THEN NULL ELSE 
	  CONVERT(DECIMAL(22, 2), REPLACE(REPLACE(REPLACE([Column 5], ',',''), '(','-'),')',''))
	   END --AS [FX_COMMISSION]
	   AS [Column 5]
      ,[Column 6] --AS [INTERNAL_REFERENCE_NUMBER]
      ,[Column 7] --AS [INTM_BANK_CORRESP_ADDRESS_1]
      ,[Column 8] --AS [INTM_BANK_CORRESP_ID]
      
	  ,CASE WHEN ISDATE([Column 9])=0 THEN NULL ELSE 
	  CONVERT(DATETIME, [Column 9]) END --AS [MT_942_CREATION_DATE]
	  AS [Column 9]
      ,CASE WHEN ISNUMERIC([Column 10])=0 THEN NULL ELSE 
	  CONVERT(INT, [Column 10]) END --AS [MARKET_RATE]
	  AS [Column 10]
      ,[Column 11] --AS [NULL_VALUE]

      ,CASE WHEN ISNUMERIC(REPLACE(REPLACE(REPLACE([Column 12], ',',''), '(','-'),')','')) = 0 THEN NULL ELSE 
	  CONVERT(DECIMAL(22, 2), REPLACE(REPLACE(REPLACE([Column 12], ',',''), '(','-'),')','')) 
	  END --AS [NET_AMNT]
	  AS [Column 12]
      ,[Column 13] --AS [ORIGINATOR_ID_CODE]
      ,[Column 14] --AS [ORIGINATOR_ID_CODE_TYPE]
      ,[Column 15] --AS [ORIGINATOR_REFERENCE]
      ,[Column 16] --AS [PAYMENT_DETAILS_CODE]

	  ,CASE WHEN ISDATE([Column 17])=0 THEN NULL ELSE
      CONVERT(DATE, [Column 17]) END --AS [PAYMENT_ORDER_DATE]
	  AS [Column 17]
      ,[Column 18] --AS [PAYMENT_ORDER_NUMBER]
      ,[Column 19] --AS [SE_CTP]
      ,[Column 20] --AS [SE_LOCA_COD_SCR]
      ,[Column 21] --AS [SOURCE_DOCUMENT]
	  
	  ,CASE WHEN ISNUMERIC([Column 22])=0 THEN NULL ELSE
      CONVERT(INT, [Column 22]) END --AS [SPREAD]
	  AS [Column 22]
      ,[Column 23] --AS [TAX_CODE]
      ,[Column 24] --AS [ULTIMATE_BENEFICIARY_ID_CODE]
      ,[Column 25] --AS [ULTIMATE_BENEFICIARY_ID_CODE_TYPE]
      ,[Column 26] --AS [ULTIMATE_BENEFICIARY_NAME]
      ,[Column 27] --AS [ULTIMATE_ORIGINATOR_ID_CODE]
      ,[Column 28] --AS [ULTIMATE_ORIGINATOR_ID_CODE_TYPE]
      ,[Column 29] --AS [ULTIMATE_ORIGINATOR_NAME]
      ,[Column 30] --AS [BANK_CORRESP_ADDRESS]
      ,[Column 31] --AS [BANK_BENEF_ADDRESS_1]
      ,[Column 32] --AS [BANK_BENEF_ADDRESS_2]
      ,[Column 33] --AS [BANK_BENEF_ADDRESS_3]
      ,[Column 34] --AS [BANK_ORDER_ADDRESS]
      ,[Column 35] --AS [BANK_ORDER_ADDRESS_1]
      ,[Column 36] --AS [BANK_ORDER_ADDRESS_2]
      ,[Column 37] --AS [BANK_ORDER_ADDRESS_3]
      ,[Column 38] --AS [BANK_INITIATOR_ADDRESS_1]
      ,[Column 39] --AS [BANK_INITIATOR_ADDRESS_2]
      ,[Column 40] --AS [BANK_INITIATOR_ADDRESS_3]
      ,[Column 41] --AS [BANK_INITIATOR_ADDRESS_4]
      ,[Column 42] --AS [BANK_CORRSP_ADDRESS_0]
      ,[Column 43] --AS [BANK_CORRESP_ADDRESS_1]
      ,[Column 44] --AS [BANK_CORRESP_ADDRESS_2]
      ,[Column 45] --AS [BANK_CORRESP_ADDRESS_3]
      ,[Column 46] --AS [BANK_INTERMEDIARY_ADDRESS_1]
      ,[Column 47] --AS [BANK_INTERMEDIARY_ADDRESS_2]
      ,[Column 48] --AS [BANK_INTERMEDIARY_ADDRESS_3]
      ,[Column 49] --AS [BENEF_ADDRESS_2]
      ,[Column 50] --AS [BENEF_ADDRESS_3]
      ,[Column 51] --AS [BENEF_ADDRESS_4]
      ,[Column 52] --AS [CORRESP_BANK_ADDRESS]
      ,[Column 53] --AS [SENDER_ADDRESS_1]
      ,[Column 54] --AS [SENDER_ADDRESS_2]
      ,[Column 55] --AS [SENDER_ADDRESS_3]
      ,[Column 56] --AS [RECIPIENT_ADDRESS_1]
      ,[Column 57] --AS [RECIPIENCE_ACCNT_ID]
      ,[Column 58] --AS [CURRENCY]
      ,[Column 59] --AS [GROSS_DIVIDEND_CURRENCY]
      ,[Column 60] --AS [TAX_CURRENCY]
      ,[Column 61] --AS [COMMISSION_WRITE_OFF_CURRENCY]
      ,[Column 62] --AS [INCOME_CURRENCY]
      ,[Column 63] --AS [COMM_CURRENCY]
      ,[Column 64] --AS [COMM_CURRENCY_BL]
      ,[Column 65] --AS [LOCAL_TAX_CURRENCY]
      ,[Column 66] --AS [BUY_CURRENCY]
      ,[Column 67] --AS [SALE_CURRENCY]

      ,CASE WHEN ISDATE([Column 68])=0 THEN NULL ELSE
	   CONVERT(DATE, [Column 68]) END --AS [CURRENCY_DATE_1]
	   AS [Column 68]
      ,CASE WHEN ISDATE([Column 69])=0 THEN NULL ELSE
	   CONVERT(DATE, [Column 69]) END --AS [CURRENCY_DATE_2]
	   AS [Column 69]
      ,CASE WHEN ISDATE([Column 70])=0 THEN NULL ELSE 
	   CONVERT(DATE, [Column 70]) END --AS [CURRENCY_DATE_3]
	   AS [Column 70]
      ,CASE WHEN ISNUMERIC([Column 71]) = 0 THEN NULL ELSE 
	   CONVERT(DECIMAL(22, 4), [Column 71]) END --AS [CURRENCY_VALUE]
      AS [Column 71]
	  ,[Column 72] --AS [INTERNAL_BANK_NMB]
      ,CASE WHEN ISNUMERIC(REPLACE(REPLACE(REPLACE([Column 73], ',',''), '(','-'),')','')) = 0 THEN NULL ELSE 
	   CONVERT(DECIMAL(22, 2), REPLACE(REPLACE(REPLACE([Column 73], ',',''), '(','-'),')','')) END --AS [OPENING_BALANCE]
	   AS [Column 73]
      ,[Column 74] --AS [INFO_1]
      ,CASE WHEN ISDATE([Column 75])=0 THEN NULL ELSE 
	   CONVERT(DATE, [Column 75]) END --AS [MAIN_CURRENCY_DATE]
	   AS [Column 75]
      ,CASE WHEN ISDATE([Column 76])=0 THEN NULL ELSE 
	   CONVERT(DATE, [Column 76]) END --AS [OUTGOING_PAYMENT_CUR_DATE]
	   AS [Column 76]
      ,CASE WHEN ISDATE([Column 77])=0 THEN NULL ELSE 
	   CONVERT(DATE, [Column 77]) END  --AS [RIGHT_DATE]
      AS [Column 77]
	  --,CASE WHEN ISDATE([Column 78])=0 THEN NULL ELSE 
	   --CONVERT(DATE, [Column 78]) END --AS [RECORD_DATE]
	  ,[Column 78]
      ,CASE WHEN ISDATE([Column 79])=0 THEN NULL ELSE 
	   CONVERT(DATE, [Column 79]) END --AS [OPERATION_RECORD_DATE]
	   AS [Column 79]
      ,CASE WHEN ISDATE([Column 80])=0 THEN NULL ELSE 
	   CONVERT(DATE, [Column 80]) END --AS [CONTRACT_CALCUL_DATE]
	   AS [Column 80]
      ,CASE WHEN ISDATE([Column 81])=0 THEN NULL ELSE 
	   CONVERT(DATE, [Column 81]) END --AS [REPORT_DATE]
	   AS [Column 81]
      ,CASE WHEN ISDATE([Column 82])=0 THEN NULL ELSE 
	   CONVERT(DATE, [Column 82]) END --AS [TRADE_OPERATION_DATE]
	   AS [Column 82]
      ,CASE WHEN ISDATE([Column 83])=0 THEN NULL ELSE 
	   CONVERT(DATETIME, [Column 83]) END --AS [DATE_L--AST_TIME]
	   AS [Column 83]
      ,CASE WHEN ISNUMERIC(REPLACE(REPLACE(REPLACE([Column 84], ',',''), '(','-'),')','')) = 0 THEN NULL ELSE 
	   CONVERT(DECIMAL(22, 2), REPLACE(REPLACE(REPLACE([Column 84], ',',''), '(','-'),')','')) END --AS [ACTUAL_OPENING_BALANCE]
	   AS [Column 84]
      ,CASE WHEN ISNUMERIC(REPLACE(REPLACE(REPLACE([Column 85], ',',''), '(','-'),')','')) = 0 THEN NULL ELSE 
	   CONVERT(DECIMAL(22, 2), REPLACE(REPLACE(REPLACE([Column 85], ',',''), '(','-'),')','')) END --AS [ACTUAL_CLOSING_BALANCE]
	    AS [Column 85]
      ,[Column 86] --AS [BANK_DETAILS]
      ,[Column 87] --AS [STATEMENT_DETAILS]
      ,[Column 88] --AS [ADD_INFO]
      ,[Column 89] --AS [LOAN_PROFIT]
      ,[Column 90] --AS [NEXT_REFERENCE]
      ,[Column 91] --AS [DUBLICATE]
      ,[Column 92] --AS [UNIT]
      ,[Column 93] --AS [REVERSE_INDICATOR]
      ,[Column 94] --AS [CORRESP_ACNT_ID_1]
      ,[Column 95] --AS [CORRESP_ACNT_ID_2]
      ,[Column 96] --AS [CLEARING_ID]
      ,[Column 97] --AS [BANK_INITIATOR_ACNT_ID]
      ,[Column 98] --AS [BENEFICIARY_NAME]
      ,[Column 99] --AS [BROKER_NAME]
      ,[Column 100] --AS [CLIENT_NAME]
      ,[Column 101] --AS [INSTRUCTION]
      ,[Column 102] --AS [TRANSFER_INFO]
      ,[Column 103] --AS [CLOSING_BALANCE]
      ,[Column 104] --AS [CLEARING_BANK_ID]
      ,[Column 105] --AS [BROKER_ID]
      ,[Column 106] --AS [BANK_RECIPIENT_ROUTING_ID]
      ,[Column 107] --AS [USA_TAX_CODE]
      ,[Column 108] --AS [SECTION_CODE]
      ,[Column 109] --AS [TRANSACTION_CODE]
      ,[Column 110] --AS [CNT_DAYS_COMMENT]
      ,[Column 111] --AS [CREDIT_RECORD_CNT]
      ,[Column 112] --AS [COMM_IS_PAID]
      ,[Column 113] --AS [CONTACT_NAME]
      ,[Column 114] --AS [CONTACT_RATE]
      ,[Column 115] --AS [CUMULAT_AMNT_REPAYMENT]
      ,[Column 116] --AS [CUMUL_CNT]
      ,[Column 117] --AS [CONVERT_RATE]
      ,[Column 118] --AS [INPUT_METHOD]
      ,[Column 119] --AS [MNEMONICS]

      --,CASE WHEN ISDATE([Column 120])=0 THEN NULL ELSE 
	  --CONVERT(DATE, [Column 120]) END --AS [ON_TODAY]
	   --AS
	  ,[Column 120]
      ,[Column 121] --AS [NAMING]
      ,[Column 122] --AS [BANK_NAME]
      ,[Column 123] --AS [ORDER_BANK_NAME]
      ,[Column 124] --AS [NEXT_SIDE_NAME]
      ,[Column 125] --AS [CORRESP_BANK_NAME]
      ,[Column 126] --AS [INTERMEDIARY_BANK_NAME]
      ,[Column 127] --AS [BENEF_BANK_NAME]
      ,[Column 128] --AS [CORRESP_BANK_NAME_2]
      ,[Column 129] --AS [COMPANY_NAME]
      ,[Column 130] --AS [BANK_PART_NAME]
      ,[Column 131] --AS [ACNT_NAME]
      ,[Column 132] --AS [TAX_INDEX]

      --,CASE WHEN ISDATE([Column 133])=0 THEN NULL ELSE 
	  --CONVERT(BIGINT, [Column 133]) END --AS [NMBR]
	   --AS
	  ,[Column 133]
      ,[Column 134] --AS [BENEFICIARY_NO_DR]

      --,CASE WHEN ISDATE([Column 135])=0 THEN NULL ELSE 
	  -- CONVERT(BIGINT, [Column 135]) END --AS [STATEMENT_NO]
	  --  AS
	  ,[Column 135]
      ,[Column 136] --AS [NO_FOR_CHECK]
      ,[Column 137] --AS [CLIENT_NO]
      ,[Column 138] --AS [NO_TRANSFER_SENDER]
      ,[Column 139] --AS [PAYMENT_NO]
      ,[Column 140] --AS [NO_CONFIRM_SEND]
      ,[Column 141] --AS [NO_ACCNT_TRANSACTION]
      ,[Column 142] --AS [NO_ACNT]
      ,[Column 143] --AS [NO_BANK_ACNT_CLIENT]
      ,[Column 144] --AS [NO_BANK_ACNT_INTERMEDIARY]
      ,[Column 145] --AS [NO_ACNT_RECEIVER]
      ,[Column 146] --AS [PHONE]
      ,[Column 147] --AS [FAX]
      ,[Column 148] --AS [NOMINAL_SUM]
      ,[Column 149] --AS [NOMINAL_SUM_PAY_OFF]
      ,[Column 150] --AS [NOMINAL_CURRENCY_RATE]
      ,[Column 151] --AS [NOMINAL_INVESTOR]
      ,[Column 152] --AS [DIVIDEND_STANDART]
      ,[Column 153] --AS [TOTAL_SUM_CREDIT]
      ,[Column 154] --AS [TOTAL_SUM_DEBIT]
      ,[Column 155] --AS [TOTAL_SUM_FLOAT_2_DAY]
      ,[Column 156] --AS [TOTAL_SUM_FLOAT_1_DAY]
      ,[Column 157] --AS [TOTAL_SUM_FLOAT_3_DAY]
      ,[Column 158] --AS [TOTAL_SUM_FLOAT_4_DAY]
      ,[Column 159] --AS [TOTAL_SUM_NETTO]
      ,[Column 160] --AS [DESCRIPTION]
      ,[Column 161] --AS [COMPANY_DESC_SE]
      ,[Column 162] --AS [OPERATION_DESC]
      ,[Column 163] --AS [DEPARTMENT_OF_CENTER]
      ,[Column 164] --AS [PRIMARY_CURRENCY]

      --,CASE WHEN ISDATE([Column 165])=0 THEN NULL ELSE 
	  -- CONVERT(DATE, [Column 165]) END --AS [PRIMARY_CURRENCY_DATE]
	  --  AS 
	  ,[Column 165]
      ,[Column 166] --AS [PRIMARY_AMNT]
      ,[Column 167] --AS [PRIMARY_AMNT_OCMP]
      ,[Column 168] --AS [PRIMARY_CURRENCY_CODE_OCMP]
      ,[Column 169] --AS [TRANSITION_TYPE_SE]
      ,[Column 170] --AS [PAYMENT_REQUISITES]
      ,[Column 171] --AS [BY_ADDRESS_ORDER]
      ,[Column 172] --AS [BY_ID_ACNT]
      ,[Column 173] --AS [CONFIM_CONFERENCES]
      ,[Column 174] --AS [DEBIT_CREDIT]
      ,[Column 175] --AS [CORRESPONDENT_BANK_ADDRESS]
      ,[Column 176] --AS [CORRESPONDENT_BANK_ADDRESS_2]
      ,[Column 177] --AS [POOL_NUMBER_PREFIX]
      ,[Column 178] --AS [INPUT_REASON]
      ,[Column 179] --AS [CHECK_LIST]
      ,[Column 180] --AS [INTEREST_RATE]
      ,[Column 181] --AS [INTEREST_RATE_SE]
      ,[Column 182] --AS [REFERENCE_BENEFICIARY]

      --,CASE WHEN ISDATE([Column 183])=0 THEN NULL ELSE 
	  -- CONVERT(DATE, [Column 183]) END --AS [FROM_DATE]
	  -- AS 
	  ,[Column 183]
      ,[Column 184] --AS [CONNECTED_LINK]
      ,[Column 185] --AS [CHEQUE_SN]
      ,[Column 186] --AS [SYSTEM_OF_SECURITIES]
      ,[Column 187] --AS [CORRESPND_PROTECTIVE_MNEMONICA]
      ,[Column 188] --AS [CORRESPOND_SERIAL_SN]
      ,[Column 189] --AS [PAYEE_CODE]

      --,CASE WHEN ISDATE([Column 190])=0 THEN NULL ELSE 
	  -- CONVERT(DATE, [Column 190]) END --AS [CONTRACT_TERM_TO_DATA]
	  --  AS 
	  ,[Column 190]
      --,CASE WHEN ISDATE([Column 191])=0 THEN NULL ELSE 
	  -- CONVERT(DATE, [Column 191]) END --AS [CONTRACT_TERM_FROM_DATA]
	  --  AS 
	  ,[Column 191]
      ,[Column 192] --AS [L/C_LINK_CITIBANK]
      ,[Column 193] --AS [L/C_LINK_DECLARANT]
      ,[Column 194] --AS [ACNT_LINK_CITIBANK]
      ,[Column 195] --AS [ACNT_LINK_DECLARANT]
      ,[Column 196] --AS [LINK_NUMBER_STATEMENT]
      ,[Column 197] --AS [SUM_BRUTO_DIVIDEND]
      ,[Column 198] --AS [SUM_TAX]
      ,[Column 199] --AS [SUM_PROFIT]
      ,[Column 200] --AS [SUM_COMMISSION]
      ,[Column 201] --AS [SUM_COMMISSION_BL]
      ,[Column 202] --AS [SUM_COMMISSION_LC]
      ,[Column 203] --AS [SUM_LOCAL_TAX]

      --,CASE WHEN ISNUMERIC(REPLACE(REPLACE(REPLACE([Column 204],',',''),'(','-'),')',''))=0 THEN 0.00 ELSE 
	  -- CONVERT(DECIMAL(31, 2), REPLACE(REPLACE(REPLACE([Column 204],',',''),'(','-'),')','')) END --AS [SUM_OPERATION]
	  --  AS 
	  ,[Column 204]
      ,[Column 205] --AS [SUM_PURCH--ASE]
      ,[Column 206] --AS [SUM_SALE]
      ,[Column 207] --AS [SUM_FLOAT_2_DAY]
      ,[Column 208] --AS [SUM_FLOAT_1_DAY]
      ,[Column 209] --AS [SUM_FLOAT_3_DAY]
      ,[Column 210] --AS [SUM_FLOAT_4_DAY]

      --,CASE WHEN ISNUMERIC(REPLACE(REPLACE(REPLACE([Column 211],',',''),'(','-'),')',''))=0 THEN 0.00 ELSE 
	  --CONVERT(DECIMAL(31, 2), REPLACE(REPLACE(REPLACE([Column 211],',',''),'(','-'),')','')) END --AS [SUM_CHEQUE]
	   --AS 
	  ,[Column 211]
      ,[Column 212] --AS [ACNT_SAFE_STORAGE]
      ,[Column 213] --AS [ACNT_PAY_COMMISSION]
      ,[Column 214] --AS [ACNT_RECEIVER_AND_OTHER_TYPE]
      ,[Column 215] --AS [ACNT_RECEIVER_AND_OTHER_ID]
      ,[Column 216] --AS [CURRENT_COEFFICIENT]
      ,[Column 217] --AS [TYPE_--ASSETS]
      ,[Column 218] --AS [TYPE_BANK_TOOL]
      ,[Column 219] --AS [TYPE_PAY]
      ,[Column 220] --AS [TYPE_ACNT]
      ,[Column 221] --AS [TYPE_SECURITIES]
      ,[Column 222] --AS [LEVEL_TAX]
      ,[Column 223] --AS [CONDITIONS_PAYMENT_BANK_CLIENT]
      ,[Column 224] --AS [CONDITIONS_PAYMENT_INTEREST]
      ,[Column 225] --AS [CONDITIONS_PAYMENT_BANK]

      --,CASE WHEN ISDATE([Column 226])=0 THEN NULL ELSE 
	  --CONVERT(DATE, [Column 226]) END --AS [ACTUAL_END_DATE]
	  --AS 
	  ,[Column 226]
      ,[Column 227] --AS [CNT_DEBIT]
      ,[Column 228] --AS [NET_CURRENCY_INCOME]
      ,[Column 229] --AS [MEMBERSHIP_NM_CMNA]
      ,[Column 230] --AS [EQUIVALENT_CURRENCY_LOCAL_TAX]
      ,[Column 231] --AS [EQUIVALENT_AMNT]
      ,[Column 232] --AS [EQUIVALENT_AMNT_LOCAL_TAX]
      ,[Column 233] --AS [NULL]
	  ,LEN(REPLACE([COLUMN 233],';','**'))-LEN([COLUMN 233]) AS SHIFT_COUNT
	  ,[Column 233] AS [COLUMN 234]
	  ,LEN(REPLACE([COLUMN 233],';','**'))-LEN([COLUMN 233]) AS SHIFT_COUNT2
  FROM [dbo].[BANK_EXTRACT_CITI]
  WHERE [Column 233] != 'Null'
  AND ISNUMERIC([COLUMN 103])!=0;
  ---------------------------------1
DECLARE @I INT;
DECLARE @KEY VARCHAR(100);
DECLARE @QUERY VARCHAR(3000);
DECLARE @COLUMN# INT;
DECLARE @COLUMNN VARCHAR(100);
DECLARE @SEQ BIGINT;
DECLARE @SEQLOG BIGINT;
DECLARE @USER VARCHAR(10);
SELECT @USER = VALUE_OUT FROM [ETL_DB]..[BANK_EXTRACT_MAIN] WHERE NAME = 'USER'; 
SELECT @SEQLOG = CONVERT(BIGINT, CURRENT_VALUE) FROM SYS.[sequences] WHERE NAME = 'SEQ_BANK_EXTRACT_LOG';
IF EXISTS (SELECT * FROM SYS.sysobjects WHERE NAME = 'BANK_EXTRACT_SHIFT_KEY') 
DROP TABLE BANK_EXTRACT_SHIFT_KEY;

--IF EXISTS (SELECT * FROM SYS.sysobjects WHERE NAME = 'BANK_EXTRACT_SHIFT_LOG_2') 
--DROP TABLE BANK_EXTRACT_SHIFT_LOG_2;
--CREATE TABLE BANK_EXTRACT_SHIFT_LOG_2 (LOG VARCHAR (1000));

CREATE TABLE [ETL_DB].[DBO].[BANK_EXTRACT_SHIFT_KEY] (SEQ BIGINT, [COLUMN#] VARCHAR(10), VALUE VARCHAR(3000), SHIFT_COUNT INT); 
SET @I = 160;

WHILE --@KEY NOT IN (SELECT DISTINCT OPERATION_DESC FROM BANK_STATEMENT_HST WHERE PARTNER_ID=1) and
 @I<=233
BEGIN
SELECT @QUERY = 'INSERT INTO [ETL_DB].[DBO].[BANK_EXTRACT_SHIFT_KEY] SELECT SEQ,' +CONVERT(VARCHAR,@I)+ ',[COLUMN '+CONVERT(VARCHAR, @I)+'], SHIFT_COUNT FROM [ETL_DB].[DBO].[BANK_EXTRACT_SHIFT_2]'; --WHERE SEQ = '+CONVERT(VARCHAR, @SEQ)
EXEC (@QUERY);
IF @@ERROR <> 0 INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQLOG, 1, 'Ошибка в процедуре PROC_EXTRACT_SHIFT_160_170 на шаге: 1. Код ошибки: ' + CONVERT(VARCHAR, @@ERROR) +' внутренний стетчик строки: '+ CONVERT(VARCHAR, @SEQ) + '. При выполнении операции: '+@QUERY, @USER, GETDATE());
SET @I=@I+1;
END;

DELETE FROM BANK_EXTRACT_SHIFT_KEY WHERE LTRIM(RTRIM(VALUE)) NOT IN (
SELECT DISTINCT OPERATION_DESC FROM BANK_STATEMENT_HST WHERE PARTNER_ID=1);
DELETE FROM BANK_EXTRACT_SHIFT_KEY WHERE VALUE = '' OR VALUE IS NULL;

SELECT @SEQ = (SELECT MIN(SEQ) FROM BANK_EXTRACT_SHIFT_KEY);
WHILE @SEQ <=(SELECT MAX(SEQ) FROM BANK_EXTRACT_SHIFT_KEY)
BEGIN
DECLARE @NSHIFT INT;


SELECT @NSHIFT = COLUMN# - 162 FROM BANK_EXTRACT_SHIFT_KEY WHERE LTRIM(RTRIM(VALUE)) IN (
SELECT DISTINCT OPERATION_DESC FROM BANK_STATEMENT_HST WHERE PARTNER_ID=1) AND SEQ = @SEQ;

DECLARE @NCOUNT INT;
SET @NCOUNT = 1;

WHILE @NCOUNT<=@NSHIFT
BEGIN
DECLARE @NUM  INT;
DECLARE @NAME VARCHAR (200);--Переменная для создания названия колонки, которую будем приклеивать
DECLARE @NQUERY VARCHAR(500);--Переменная запроса
SET @NUM = 160+@NCOUNT;--Отсчет ведем от 160 колонки (исходной колонки в которой прошел разбив)
SET @NAME = ' +'';''+ [COLUMN '+CONVERT(VARCHAR, @NUM) + ']';--Формируем название колонки, которую будем присоединять

SELECT @NQUERY = 'UPDATE [ETL_DB].[DBO].[BANK_EXTRACT_SHIFT_2] SET [COLUMN 160] = [COLUMN 160] +'+@NAME+' WHERE [SEQ] = '+CONVERT(VARCHAR, @SEQ)--Формируем запрос, кооторый будет выполняться для конкатенации
--INSERT INTO BANK_EXTRACT_SHIFT_LOG_2 VALUES ('NQUERY = '+@NQUERY);--Записываем запрос в лог
EXEC (@NQUERY);--Выполняем сформированный запрос
IF @@ERROR <> 0 INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQLOG, 1, 'Ошибка в процедуре PROC_EXTRACT_SHIFT_160_170 на шаге: 2. Код ошибки: ' + CONVERT(VARCHAR, @@ERROR) +' внутренний стетчик строки: '+ CONVERT(VARCHAR, @SEQ) + '. При выполнении операции: '+@NQUERY, @USER, GETDATE());
SET @NCOUNT = @NCOUNT+1; 
END;

DECLARE @NT INT;
DECLARE @NY INT;
DECLARE @SHIFT_COUNT INT;
DECLARE @NCNAME VARCHAR(500);
DECLARE @NANAME VARCHAR(500);
DECLARE @NEWQUERY VARCHAR(3000);
SELECT @SHIFT_COUNT = SHIFT_COUNT FROM BANK_EXTRACT_SHIFT_2 WHERE SEQ=@SEQ;
SET @NT = 161;
SELECT @NY = COLUMN#-162 FROM BANK_EXTRACT_SHIFT_KEY WHERE LTRIM(RTRIM(VALUE)) IN (
SELECT DISTINCT OPERATION_DESC FROM BANK_STATEMENT_HST WHERE PARTNER_ID=1) AND SEQ = @SEQ;

UPDATE BANK_EXTRACT_SHIFT_2 SET SHIFT_COUNT = SHIFT_COUNT - @NY WHERE SEQ=@SEQ;

WHILE --@NT<232 OR
 @NT+@NY<233---@SHIFT_COUNT--Выделяем диапозон колонок
BEGIN
--INSERT INTO BANK_EXTRACT_SHIFT_LOG_2 VALUES ('NT = '+CONVERT(VARCHAR, @NT));--Записываем значения в лог
SET @NCNAME = 'CONVERT(VARCHAR(MAX), [COLUMN '+CONVERT(VARCHAR, (@NY+@NT)) + '])';--Формируем название колонки, которую будем копировать
SET @NANAME = '[COLUMN '+CONVERT(VARCHAR, @NT) + ']';--Формируем название колонки, в которую будем копировать
--Формируем запрос для выполнение копирования
SELECT @NEWQUERY = 'UPDATE [ETL_DB].[DBO].[BANK_EXTRACT_SHIFT_2] SET '+@NANAME+' = '+@NCNAME+' WHERE [SEQ] = '+CONVERT(VARCHAR, @SEQ)
--INSERT INTO BANK_EXTRACT_SHIFT_LOG_2 VALUES ('QUERY_UPDATE = '+@NEWQUERY);--Записываем в лог
EXEC (@NEWQUERY);--Выполняем сформированный запрос
IF @@ERROR <> 0 INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQLOG, 1, 'Ошибка в процедуре PROC_EXTRACT_SHIFT_160_170 на шаге: 3. Код ошибки: ' + CONVERT(VARCHAR, @@ERROR) +' внутренний стетчик строки: '+ CONVERT(VARCHAR, @SEQ) + '. При выполнении операции: '+@NEWQUERY, @USER, GETDATE());
SET @NT=@NT+1;--Увеличиваем счетчик колонки
END;

SET @SEQ = @SEQ+1;
END;

-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------

------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------

IF EXISTS (SELECT * FROM SYS.sysobjects WHERE NAME = 'BANK_EXTRACT_SHIFT_KEY') 
DROP TABLE BANK_EXTRACT_SHIFT_KEY;

CREATE TABLE [ETL_DB].[DBO].[BANK_EXTRACT_SHIFT_KEY] (SEQ BIGINT, [COLUMN#] VARCHAR(10), VALUE VARCHAR(3000), SHIFT_COUNT INT); 


SET @I = 170;
WHILE 
 @I<=233
BEGIN
SELECT @QUERY = 'INSERT INTO [ETL_DB].[DBO].[BANK_EXTRACT_SHIFT_KEY] SELECT SEQ,' +CONVERT(VARCHAR,@I)+ ',[COLUMN '+CONVERT(VARCHAR, @I)+'], SHIFT_COUNT FROM [ETL_DB].[DBO].[BANK_EXTRACT_SHIFT_2]'; 
EXEC (@QUERY);
--INSERT INTO [ETL_DB].[DBO].[BANK_EXTRACT_SHIFT_t_log] VALUES (@QUERY);
IF @@ERROR <> 0 INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQLOG, 1, 'Ошибка в процедуре PROC_EXTRACT_SHIFT_160_170 на шаге: 4. Код ошибки: ' + CONVERT(VARCHAR, @@ERROR) +' внутренний стетчик строки: '+ CONVERT(VARCHAR, @SEQ) + '. При выполнении операции: '+@QUERY, @USER, GETDATE());
SET @I=@I+1;
END;


DELETE FROM BANK_EXTRACT_SHIFT_KEY WHERE LTRIM(RTRIM(VALUE)) NOT IN (
SELECT DISTINCT INPUT_REASON FROM BANK_STATEMENT_HST WHERE PARTNER_ID=1);
DELETE FROM BANK_EXTRACT_SHIFT_KEY WHERE VALUE = '' OR VALUE IS NULL;

SELECT @SEQ = (SELECT MIN(SEQ) FROM BANK_EXTRACT_SHIFT_2);
WHILE @SEQ <=(SELECT MAX(SEQ) FROM BANK_EXTRACT_SHIFT_2)
BEGIN
SELECT @NSHIFT = COLUMN# - 178 FROM BANK_EXTRACT_SHIFT_KEY WHERE SEQ = @SEQ;
SET @NCOUNT = 1;

WHILE @NCOUNT<=@NSHIFT
BEGIN
SET @NUM = 170+@NCOUNT;--Отсчет ведем от 170 колонки (исходной колонки в которой прошел разбив)
SET @NAME = ' +'';''+ [COLUMN '+CONVERT(VARCHAR, @NUM) + ']';--Формируем название колонки, которую будем присоединять

SELECT @NQUERY = 'UPDATE [ETL_DB].[DBO].[BANK_EXTRACT_SHIFT_2] SET [COLUMN 170] = [COLUMN 170] +'+@NAME+' WHERE [SEQ] = '+CONVERT(VARCHAR, @SEQ)--Формируем запрос, кооторый будет выполняться для конкатенации
--INSERT INTO BANK_EXTRACT_SHIFT_LOG_2 VALUES ('NQUERY = '+@NQUERY);--Записываем запрос в лог
EXEC (@NQUERY);--Выполняем сформированный запрос
IF @@ERROR <> 0 INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQLOG, 1, 'Ошибка в процедуре PROC_EXTRACT_SHIFT_160_170 на шаге: 5. Код ошибки: ' + CONVERT(VARCHAR, @@ERROR) +' внутренний стетчик строки: '+ CONVERT(VARCHAR, @SEQ) + '. При выполнении операции: '+@NQUERY, @USER, GETDATE());
SET @NCOUNT = @NCOUNT+1; 
END;

SELECT @SHIFT_COUNT = SHIFT_COUNT FROM BANK_EXTRACT_SHIFT_2 WHERE SEQ=@SEQ;
SET @NT = 171;
SELECT @NY = COLUMN#-178 FROM BANK_EXTRACT_SHIFT_KEY WHERE SEQ = @SEQ;

WHILE (@NT<=232-@SHIFT_COUNT) AND (@NT+@NY <=233) --Выделяем диапозон колонок
BEGIN
--INSERT INTO BANK_EXTRACT_SHIFT_LOG_2 VALUES ('NT = '+CONVERT(VARCHAR, @NT));--Записываем значения в лог
SET @NCNAME = 'CONVERT(VARCHAR, [COLUMN '+CONVERT(VARCHAR, (@NY+@NT)) + '])';--Формируем название колонки, которую будем копировать
SET @NANAME = '[COLUMN '+CONVERT(VARCHAR, @NT) + ']';--Формируем название колонки, в которую будем копировать
--Формируем запрос для выполнение копирования
SELECT @NEWQUERY = 'UPDATE [ETL_DB].[DBO].[BANK_EXTRACT_SHIFT_2] SET '+@NANAME+' = '+@NCNAME+' WHERE [SEQ] = '+CONVERT(VARCHAR, @SEQ)
--INSERT INTO BANK_EXTRACT_SHIFT_LOG_2 VALUES ('QUERY_UPDATE = '+@NEWQUERY);--Записываем в лог
EXEC (@NEWQUERY);--Выполняем сформированный запрос
IF @@ERROR <> 0 INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQLOG, 1, 'Ошибка в процедуре PROC_EXTRACT_SHIFT_160_170 на шаге: 6. Код ошибки: ' + CONVERT(VARCHAR, @@ERROR) +' внутренний стетчик строки: '+ CONVERT(VARCHAR, @SEQ) + '. При выполнении операции: '+@NEWQUERY, @USER, GETDATE());
SET @NT=@NT+1;--Увеличиваем счетчик колонки
END;

SET @SEQ = @SEQ+1;
END;

--------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------
SELECT @SEQ = (SELECT MIN(SEQ) FROM BANK_EXTRACT_SHIFT_2);
WHILE @SEQ <=(SELECT MAX(SEQ) FROM BANK_EXTRACT_SHIFT_2)
BEGIN

--Цикл по разделению последней 233 строки и записи данных в диапазон между 233-SHIFT_COUNT и 232 колонкой
DECLARE @COL234 VARCHAR(2000);
DECLARE @PARSE VARCHAR(2000);
DECLARE @Y INT;
DECLARE @PARQUERY VARCHAR(2000);
SELECT @SHIFT_COUNT = SHIFT_COUNT2 FROM BANK_EXTRACT_SHIFT_2 WHERE SEQ=@SEQ;
SET @Y = 233 - @SHIFT_COUNT;
--INSERT INTO BANK_EXTRACT_SHIFT_LOG_2 VALUES ('Y = '+CONVERT(VARCHAR, @Y));--Записываем в лог счетчик
--Начинаем цикл
WHILE @Y<233
BEGIN 
--Разбираем строку по ключевому символу ";"
SELECT 
@PARSE = SUBSTRING([COLUMN 234],1,CHARINDEX(';', [COLUMN 234])), --Выделяем значение, которое будет копировать в колонки
--Выделяем остаток отсечения
@COL234 = SUBSTRING ([COLUMN 234],
			         CHARINDEX(';', 
			                   [COLUMN 234])+1, 
						       LEN ([COLUMN 234]) - CHARINDEX(';', [COLUMN 234]))
FROM BANK_EXTRACT_SHIFT_2 WHERE SEQ = @SEQ;
--INSERT INTO BANK_EXTRACT_SHIFT_LOG_2 VALUES ('PARSE = '+@PARSE);--Все пишем в лог
--INSERT INTO BANK_EXTRACT_SHIFT_LOG_2 VALUES ('COL234 = '+@COL234);--Все пишем в лог
IF @PARSE = ';' SET @PARSE = ' ';--Пустое значение
--А вот и не пустое значение
IF LEN(@PARSE)>1 AND @PARSE LIKE '%;'

BEGIN
--Отрезаем ключевой символ ";"
SET @PARSE = SUBSTRING(@PARSE, 1, LEN(@PARSE)-1);
END;
--Пишем в лог
--INSERT INTO BANK_EXTRACT_SHIFT_LOG_2 VALUES ('PARSE = '+CONVERT(VARCHAR, @PARSE));
--Обновляем колонку 234 остатком от разделения
UPDATE BANK_EXTRACT_SHIFT_2 SET [COLUMN 234] = @COL234 WHERE SEQ = @SEQ;
--Формируем запрос обновления колонок
SET @PARQUERY = 'UPDATE [ETL_DB].[DBO].[BANK_EXTRACT_SHIFT_2] SET [COLUMN '+CONVERT(VARCHAR, @Y)+'] = CONVERT(VARCHAR, '''+@PARSE + ''') WHERE SEQ = '+CONVERT(VARCHAR, @SEQ)+';'
--Выполняем запрос
EXEC (@PARQUERY);
IF @@ERROR <> 0 INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQLOG, 1, 'Ошибка в процедуре PROC_EXTRACT_SHIFT_160_170 на шаге: 7. Код ошибки: ' + CONVERT(VARCHAR, @@ERROR) +' внутренний стетчик строки: '+ CONVERT(VARCHAR, @SEQ) + '. При выполнении операции: '+@PARQUERY, @USER, GETDATE());
--Логируем
--INSERT INTO BANK_EXTRACT_SHIFT_LOG_2 VALUES ('PARQUERY = '+@PARQUERY);
--Увеличиваем счетчик колонок
SET @Y=@Y+1;
END;

SET @SEQ = @SEQ+1;
END;

DECLARE @COUNT INT;
SELECT @COUNT = COUNT(*) FROM BANK_EXTRACT_SHIFT_2;
INSERT INTO [ETL_DB]..[BANK_EXTRACT_LOG] VALUES (@SEQLOG, 0, 'Процедура сдвига PROC_EXTRACT_SHIFT_160_170 сформировала: '+CONVERT(VARCHAR, @COUNT)+' записей.', @USER, GETDATE());


--IF EXISTS (SELECT * FROM SYS.sysobjects WHERE NAME = 'BANK_EXTRACT_SHIFT_LOG_2') DROP TABLE BANK_EXTRACT_SHIFT_LOG_2;
IF EXISTS (SELECT * FROM SYS.sysobjects WHERE NAME = 'BANK_EXTRACT_SHIFT_KEY') DROP TABLE BANK_EXTRACT_SHIFT_KEY;

END




