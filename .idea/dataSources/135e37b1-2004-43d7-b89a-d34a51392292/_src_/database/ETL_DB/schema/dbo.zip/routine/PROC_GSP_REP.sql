CREATE PROCEDURE [dbo].[PROC_GSP_REP] (@POLNUM VARCHAR(10))
AS
BEGIN 
DECLARE @QUERY VARCHAR(1000);
DECLARE @QUERY2 VARCHAR(1000);
DECLARE @FILE VARCHAR(50);
DECLARE @FILE2 VARCHAR(50);
DECLARE @SEQ INT;
SELECT @SEQ = NEXT VALUE FOR SEQ_GSP_REP;
SET @FILE = 'D:\99.15_GSP_REP_CERT\data\from_GSP.xml';
SET @FILE2 = 'D:\99.15_GSP_REP_CERT\data\Polnum.txt';
SET @QUERY2 = 'SELECT '+@POLNUM+ ' AS A';
SET @QUERY2 = 'EXEC xp_cmdshell ''bcp "select ''''' + @POLNUM + ''''' AS F" queryout "'+@file2+'" -T -c -C{ACP} -v -t,''';
SET @QUERY = 'SELECT a.XML_Data + ''''</ApplicationData></POSReportData>'''' as XML_Data FROM  OPENQUERY([RU-PII-2K8-D01],''''SELECT Cast(sl_xml_txt as Varchar(MAX)) as XML_Data FROM [GSP].[DBO].[T_SL_APP] WHERE APP_NUM='''''''''+@POLNUM+''''''''' '''') a';
SET @QUERY = 'EXEC xp_cmdshell ''bcp "' + @QUERY + '" queryout "'+@file+'" -T -c -C{ACP} -v -t,''';
INSERT INTO GSP_REP_LOG VALUES (@SEQ, @POLNUM, @QUERY, GETDATE());
EXEC(@QUERY);
EXEC(@QUERY2);
SET @QUERY = 'EXEC XP_CMDSHELL "D:\99.15_GSP_REP_CERT\bin\merge.cmd"';
EXEC(@QUERY);
END;
