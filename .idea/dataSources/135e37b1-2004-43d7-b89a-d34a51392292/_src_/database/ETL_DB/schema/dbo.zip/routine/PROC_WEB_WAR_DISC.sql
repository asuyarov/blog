CREATE PROCEDURE [dbo].[PROC_WEB_WAR_DISC]
 (@NAME VARCHAR(8))
AS
BEGIN 
DECLARE @EXEC VARCHAR(100);
SET @EXEC = 'execute (''begin sys.ins20c_disconnect_user('''''+@NAME+'''''); end;'') at [RU-PII-IBS-D01] ';
exec (@exec);
EXECUTE ('select * from ins.tbl_it_help_20c where rowid=(select max(rowid) from ins.tbl_it_help_20c)') at [RU-PII-IBS-D01];
END;
