
CREATE PROCEDURE [dbo].[PROC_WEB_WAR_GETLOG] 
AS
BEGIN 
truncate table WEB_WAR_REPORT;
INSERT WEB_WAR_REPORT
execute ('select * from ins.tbl_it_help_20c order by 1 asc') at [RU-PII-IBS-D01];
SELECT id, log, convert(varchar, log_date, 120) as LOG_DATE FROM WEB_WAR_REPORT;
END;