CREATE PROCEDURE [dbo].[PROC_WEB_WAR_SENDMAIL] (@EMAIL VARCHAR(100))
AS
BEGIN 
set language RUSSIAN;
--Объявление переменных задания
declare @query varchar (300);
declare @query2 varchar (300);
declare @file varchar(50);
declare @file2 varchar(50);
--Название задания
truncate table WEB_WAR_REPORT;
INSERT WEB_WAR_REPORT
execute ('select * from ins.tbl_it_help_20c order by 1 asc') at [RU-PII-IBS-D01];
set @file = 'D:\99.11_ROSFEEDDATA\text_for_email.txt'
set @file2 = 'D:\99.11_ROSFEEDDATA\text_to_email.txt'
set @query = 'SELECT * FROM ETL_DB.DBO.WEB_WAR_REPORT'
set @query = 'EXEC xp_cmdshell ''bcp "' + @query + '" queryout "'+@file+'" -T -c -C{ACP} -v -t,''';
set @query2 = 'select @email';
set @email = ''''+@email+'''';
set @query2 = 'EXEC xp_cmdshell ''bcp  "select ''' + @email + '''" queryout "'+@file2+'" -T -c -C{ACP} -v -t,''';
print @query2;
exec (@query);
print @query;
exec (@query2);
SET @FILE = 'D:\99.11_ROSFEEDDATA\mail_for_web.vbs'
SET @query = 'exec xp_cmdshell ''cscript "'+@file+'"'''
exec (@query);

END;