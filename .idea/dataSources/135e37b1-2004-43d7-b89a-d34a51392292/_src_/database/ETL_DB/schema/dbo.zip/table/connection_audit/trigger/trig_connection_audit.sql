CREATE TRIGGER [dbo].[trig_connection_audit] ON [ETL_DB].[dbo].[connection_audit]
for insert
AS
BEGIN
SET NOCOUNT ON


BEGIN
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	DECLARE @QUERY VARCHAR(1000);
    DECLARE @FILE VARCHAR(50);
    SET @FILE = 'D:\99.13_AGLST_PROC\JOB_REPORT_DIS.txt';
    SET @QUERY = 'SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED; select TOP 1 ''''<tr><td>''''+rtrim(ltrim(JOB_NAME))+''''</td>''''+''''<td>''''+rtrim(ltrim(LOGINAME))+''''</td>''''+''''<td>''''+rtrim(ltrim(HOSTNAME))+''''</td>''''+''''<td>''''+rtrim(ltrim(PROGRAM_NAME))+''''</td>''''+''''<td>''''+rtrim(ltrim(CMD))+''''</td>''''+''''<td>''''+rtrim(ltrim(CONVERT(VARCHAR, LAST_BATCH, 121)))+''''</td>''''+''''<td>''''+rtrim(ltrim(CONVERT(VARCHAR, DATE_MODIFIED, 121)))+''''</td></tr>'''' from [ETL_DB].[dbo].[who_disabled_job] where DATE_MODIFIED = (select max(DATE_MODIFIED) from [etl_db].[dbo].[who_disabled_job])';
    SET @QUERY = 'EXEC xp_cmdshell ''bcp "' + @QUERY + '" queryout "'+@file+'" -T -c -C{ACP} -v -t,''';
    EXEC(@QUERY);
    SET @FILE = 'D:\99.13_AGLST_PROC\mail_report_DIS.vbs';
    SET @QUERY = 'exec xp_cmdshell ''cscript "'+@FILE+'"''';
    EXEC(@QUERY);
END

END
