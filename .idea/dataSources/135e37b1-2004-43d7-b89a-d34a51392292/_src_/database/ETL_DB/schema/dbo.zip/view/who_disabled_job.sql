create view dbo.who_disabled_job
as
SELECT name AS job_name, loginame, hostname, program_name, cmd, last_batch, c.date_modified
FROM  dbo.connection_audit c INNER JOIN dbo.job_audit j ON c.date_modified = j.date_modified
WHERE cmd = 'INSERT' and dbname = 'msdb'